from scripts.runtime import config
from scripts.workloads.concurrency_benchmark import ConcurrencyBenchmark, pending_concurrency_levels


def test_pending_concurrency_levels_preserve_order_and_skip_completed_levels():
    attempts = {1: None, 2: 2, 4: 1}
    assert pending_concurrency_levels([1, 2, 4], attempts.get) == [(2, 2), (4, 1)]
from scripts.runtime.engines.base import GenerationMeasurement
from scripts.runtime.shared import Shared


def test_below_floor_never_stops_even_if_slow():
    floor = config.CONCURRENCY_CHAT_MIN_LEVEL_BEFORE_SOFT_EXIT
    assert ConcurrencyBenchmark.should_stop_escalating(
        1, mean_tps=1.0, force_all=False, soft_exit_floor=floor) is False
    assert ConcurrencyBenchmark.should_stop_escalating(
        floor - 1, mean_tps=1.0, force_all=False, soft_exit_floor=floor) is False


def test_at_floor_stops_when_below_cutoff():
    floor = config.CONCURRENCY_CHAT_MIN_LEVEL_BEFORE_SOFT_EXIT
    assert ConcurrencyBenchmark.should_stop_escalating(
        floor, mean_tps=config.SLOW_MODEL_MIN_TPS - 1, force_all=False, soft_exit_floor=floor) is True


def test_at_floor_does_not_stop_when_above_cutoff():
    floor = config.CONCURRENCY_CHAT_MIN_LEVEL_BEFORE_SOFT_EXIT
    assert ConcurrencyBenchmark.should_stop_escalating(
        floor, mean_tps=config.SLOW_MODEL_MIN_TPS + 1, force_all=False, soft_exit_floor=floor) is False


def test_above_floor_stops_when_below_cutoff():
    floor = config.CONCURRENCY_CHAT_MIN_LEVEL_BEFORE_SOFT_EXIT
    assert ConcurrencyBenchmark.should_stop_escalating(
        32, mean_tps=config.SLOW_MODEL_MIN_TPS - 1, force_all=False, soft_exit_floor=floor) is True


def test_force_all_disables_soft_exit_even_past_floor():
    floor = config.CONCURRENCY_CHAT_MIN_LEVEL_BEFORE_SOFT_EXIT
    assert ConcurrencyBenchmark.should_stop_escalating(
        32, mean_tps=0.1, force_all=True, soft_exit_floor=floor) is False


def test_none_floor_never_stops_regardless_of_level_or_speed():
    # The tool test's shape: soft_exit_floor=None means only a hard stop
    # (crash/load-failure) ends the sweep early, never the tok/s cutoff.
    assert ConcurrencyBenchmark.should_stop_escalating(
        8, mean_tps=0.01, force_all=False, soft_exit_floor=None) is False
    assert ConcurrencyBenchmark.should_stop_escalating(
        1, mean_tps=0.01, force_all=False, soft_exit_floor=None) is False


def test_slot_ctx_for_adds_generation_headroom_to_padded_prompt():
    # Slot ctx must exceed the prompt target or generation has no room.
    assert ConcurrencyBenchmark.slot_ctx_for(4096) == 4096 + config.GENERATE_MAX_TOKENS


def test_slot_ctx_for_also_reserves_chat_template_headroom():
    assert ConcurrencyBenchmark.slot_ctx_for(512, 2048) == 3072


class _FakeEngine:
    name = "fake"

    def __init__(self):
        self.seen_prompts = []
        self.seen_num_ctx = []

    def generation_prompt_headroom(self):
        return 0

    def generate(self, tag, prompt, timeout, per_request_context, level):
        self.seen_prompts.append(prompt)
        self.seen_num_ctx.append(per_request_context)
        return (0.1, 10, 100.0)


def test_fire_batch_returns_one_sample_per_concurrent_request():
    engine = _FakeEngine()
    samples = ConcurrencyBenchmark._fire_batch(engine, "tag", 4, 2048)
    assert samples == [(0.1, 10, 100.0)] * 4


def test_fire_batch_passes_slot_ctx_with_generation_headroom_not_bare_prompt_size():
    engine = _FakeEngine()
    ConcurrencyBenchmark._fire_batch(engine, "tag", 2, 4096)
    assert engine.seen_num_ctx == [4096 + config.GENERATE_MAX_TOKENS] * 2


def test_fire_batch_gives_each_concurrent_request_a_distinct_prompt():
    # Without a unique nonce per request, a prefix cache would serve some requests near-instantly.
    engine = _FakeEngine()
    ConcurrencyBenchmark._fire_batch(engine, "tag", 5, 512)
    assert len(engine.seen_prompts) == 5
    assert len(set(engine.seen_prompts)) == 5


def test_fire_batch_propagates_a_request_failure():
    class CrashingEngine:
        name = "fake"

        def generation_prompt_headroom(self):
            return 0

        def generate(self, tag, prompt, timeout, per_request_context, level):
            raise RuntimeError("boom")

    try:
        ConcurrencyBenchmark._fire_batch(CrashingEngine(), "tag", 2, 512)
        assert False, "expected RuntimeError to propagate"
    except RuntimeError as e:
        assert "boom" in str(e)


class _RetryEngine:
    def __init__(self, recovers=True):
        self.recovers = recovers
        self.recovery_calls = 0

    def is_connection_crash(self, error):
        return isinstance(error, ConnectionError)

    def wait_for_recovery(self):
        self.recovery_calls += 1
        return self.recovers


def test_fire_batch_retries_transient_connection_crash(monkeypatch):
    outcomes = iter([ConnectionError("down"), [(0.1, 2, 3.0)]])

    def fire(*args):
        outcome = next(outcomes)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    monkeypatch.setattr(ConcurrencyBenchmark, "_fire_batch", staticmethod(fire))
    engine = _RetryEngine()
    samples, status, error, elapsed = ConcurrencyBenchmark._fire_batch_with_crash_retries(
        engine, "tag", 1, 512,
    )
    assert samples == [(0.1, 2, 3.0)]
    assert status == "ok"
    assert error is None
    assert elapsed >= 0
    assert engine.recovery_calls == 1


def test_fire_batch_reports_crash_only_after_retry_limit(monkeypatch):
    calls = []

    def fire(*args):
        calls.append(True)
        raise ConnectionError("down")

    monkeypatch.setattr(ConcurrencyBenchmark, "_fire_batch", staticmethod(fire))
    engine = _RetryEngine()
    samples, status, error, elapsed = ConcurrencyBenchmark._fire_batch_with_crash_retries(
        engine, "tag", 2, 512,
    )
    assert samples == []
    assert status == "crashed"
    assert isinstance(error, ConnectionError)
    assert elapsed == 0
    assert len(calls) == Shared.CRASH_RETRY_MAX + 1


def test_fire_batch_does_not_retry_non_connection_failure(monkeypatch):
    monkeypatch.setattr(
        ConcurrencyBenchmark, "_fire_batch",
        staticmethod(lambda *args: (_ for _ in ()).throw(ValueError("bad response"))),
    )
    samples, status, error, elapsed = ConcurrencyBenchmark._fire_batch_with_crash_retries(
        _RetryEngine(), "tag", 2, 512,
    )
    assert samples == []
    assert status == "failed"
    assert isinstance(error, ValueError)
    assert elapsed == 0


def test_fire_batch_stops_when_engine_cannot_recover(monkeypatch):
    monkeypatch.setattr(
        ConcurrencyBenchmark, "_fire_batch",
        staticmethod(lambda *args: (_ for _ in ()).throw(ConnectionError("down"))),
    )
    engine = _RetryEngine(recovers=False)
    _, status, error, _ = ConcurrencyBenchmark._fire_batch_with_crash_retries(
        engine, "tag", 2, 512,
    )
    assert status == "crashed"
    assert isinstance(error, ConnectionError)
    assert engine.recovery_calls == 1


def test_fire_batch_negative_retry_limit_returns_defensive_fallback(monkeypatch):
    monkeypatch.setattr(Shared, "CRASH_RETRY_MAX", -1)
    result = ConcurrencyBenchmark._fire_batch_with_crash_retries(
        _RetryEngine(), "tag", 2, 512,
    )
    assert result == ([], "crashed", None, 0)


def _concurrency_measurement(implausible=False):
    return GenerationMeasurement(
        client_ttft_sec=0.1, generated_tokens=10, tokens_per_sec=20,
        client_wall_sec=0.6, decode_sec=0.5,
        server_tps_implausible=implausible,
    )


def test_measured_batch_retries_entire_batch_once_after_implausible_tps(monkeypatch):
    outcomes = iter([
        ([_concurrency_measurement(True)], "ok", None, 1.0),
        ([_concurrency_measurement(False)], "ok", None, 2.0),
    ])
    monkeypatch.setattr(
        ConcurrencyBenchmark, "_fire_batch_with_crash_retries",
        staticmethod(lambda *args: next(outcomes)),
    )
    samples, status, _, elapsed = ConcurrencyBenchmark._fire_measured_batch(
        object(), "tag", 4, 512, "Model",
    )
    assert status == "ok"
    assert samples[0].server_tps_implausible is False
    assert elapsed == 2.0


def test_measured_batch_returns_second_implausible_batch_without_third_attempt(monkeypatch):
    calls = []

    def fire(*args):
        calls.append(True)
        return [_concurrency_measurement(True)], "ok", None, 1.0

    monkeypatch.setattr(
        ConcurrencyBenchmark, "_fire_batch_with_crash_retries", staticmethod(fire),
    )
    samples, status, _, _ = ConcurrencyBenchmark._fire_measured_batch(
        object(), "tag", 4, 512, "Model",
    )
    assert status == "ok"
    assert samples[0].server_tps_implausible is True
    assert len(calls) == 2
