from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[1]
QUALIFICATION = ROOT / "qualification"


def test_root_keeps_only_primary_run_launchers():
    root_runners = {
        path.name for path in ROOT.iterdir()
        if path.is_file() and path.name.startswith("run_")
        and path.suffix in {".sh", ".bat", ".ps1"}
    }
    assert root_runners == {"run_bench.sh", "run_bench.bat"}


def test_qualification_launchers_live_together():
    assert {path.name for path in QUALIFICATION.iterdir() if path.is_file()} == {
        "qual.sh",
        "qual_windows.bat",
        "qual_windows.ps1",
        "run_power_qualification_m5_pro.sh",
        "run_qualification.bat",
        "run_qualification.sh",
        "run_sustained_qualification_linux.sh",
        "run_telemetry_trials.sh",
        "run_temperature_qualification_linux.sh",
    }


def test_unix_launcher_runs_normal_setup_then_normal_benchmark_wrapper():
    text = (QUALIFICATION / "run_qualification.sh").read_text()
    assert 'bash "$ROOT/setup.sh"' in text
    assert '--qualification "$ENGINE" --qualification-target "$TARGET"' in text
    assert "scripts.release.qualification_run" in text
    assert "qualification-env" not in text
    assert "qualification_automation" not in text
    assert '$ROOT/qualification-evidence/$TARGET/results_qualification_${TARGET}.json' in text
    assert 'tee -a "$SETUP_LOG"' not in text
    assert 'tail -c +"$LOG_OFFSET" -f "$SETUP_LOG" &' in text
    assert "trap stop_log_follower EXIT INT TERM" in text
    assert 'kill "$LOG_FOLLOWER_PID"' in text
    assert '--qualification "$ENGINE" --qualification-target "$TARGET" >> "$SETUP_LOG" 2>&1' in text
    assert 'SETUP_RESULT="reboot_required"' in text
    assert "NVIDIA driver installation completed. Reboot" in text
    assert '"schema": "qualification-setup-v1"' in text
    assert 'chmod 0644 "$SETUP_LOG" "$SETUP_STATUS"' in text


def test_windows_launcher_runs_normal_setup_then_normal_benchmark_wrapper():
    text = (QUALIFICATION / "run_qualification.bat").read_text()
    assert "qualification_setup.ps1" in text
    assert "scripts.release.qualification_run" in text
    assert "qualification-env" not in text
    assert "qualification_automation" not in text
    assert "powershell.exe -NoProfile" in text
    assert "qualification_targets.ps1" in text
    assert "ForEach-Object" not in text
    assert all(" | " not in line for line in text.splitlines()
               if line.startswith("powershell.exe"))
    assert "for /f" not in text
    assert "%CD%\\qualification-evidence\\%TARGET%\\results_qualification_%TARGET%.json" in text


def test_windows_setup_capture_retains_log_and_machine_readable_status():
    text = (ROOT / "scripts" / "release" / "qualification_setup.ps1").read_text()
    assert "Tee-Object -FilePath $log -Append" in text
    assert '$ErrorActionPreference = "Continue"' in text
    assert "$ErrorActionPreference = $previousErrorActionPreference" in text
    assert "catch {" in text
    assert 'schema = "qualification-setup-v1"' in text
    assert 'status = "running"' in text
    assert 'log = "setup.log"' in text
    assert "exit $setupExit" in text


def test_windows_target_helper_lists_and_validates_the_shared_target_registry():
    text = (ROOT / "scripts" / "release" / "qualification_targets.ps1").read_text()
    assert 'Join-Path $PSScriptRoot "qualification_targets.py"' in text
    assert "foreach ($match in [regex]::Matches" in text
    assert "if ($ids -contains $Target)" in text
    assert "Write-Output $id" in text


def test_default_qualification_output_directory_is_gitignored():
    assert "/qualification-evidence/" in (ROOT / ".gitignore").read_text().splitlines()


def test_qualification_results_are_not_tracked():
    result = subprocess.run(
        ["git", "ls-files", "qualification-evidence"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout == ""


def test_posix_qualification_launcher_has_valid_shell_syntax():
    result = subprocess.run(
        ["/bin/bash", "-n", QUALIFICATION / "run_qualification.sh"], capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr


def test_target_listing_needs_no_python_environment():
    result = subprocess.run(
        [QUALIFICATION / "run_qualification.sh", "--list-targets"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == [
        "macos-m5-pro-llamacpp-metal",
        "geforce-windows-llamacpp-cuda",
        "radeon-windows-llamacpp-vulkan",
        "intel-arc-windows-llamacpp-sycl",
        "geforce-wsl2-llamacpp-cuda",
        "geforce-wsl2-vllm-cuda",
        "radeon-wsl2-llamacpp-rocm",
        "nvidia-linux-llamacpp-cuda",
        "nvidia-linux-vllm-cuda",
        "radeon-linux-llamacpp-rocm",
        "radeon-linux-vllm-rocm",
        "intel-arc-linux-llamacpp-sycl",
        "intel-arc-linux-vllm-xpu",
        "ryzen-ai-halo-llamacpp-rocm",
        "ryzen-ai-halo-vllm-rocm",
        "dgx-spark-llamacpp-cuda",
        "dgx-spark-vllm-cuda",
    ]


def test_unknown_target_is_rejected_before_setup():
    result = subprocess.run(
        [QUALIFICATION / "run_qualification.sh", "invented-target"],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 2
    assert "Unknown qualification target" in result.stderr
