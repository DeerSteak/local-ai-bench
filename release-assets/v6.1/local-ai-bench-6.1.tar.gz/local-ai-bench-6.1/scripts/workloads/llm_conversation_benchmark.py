"""Simulates a real multi-turn chat, grown from empty toward the model's real
context ceiling. See docs/workloads.md's conversation-test section."""

from pathlib import Path

from scripts.runtime import config
from scripts.runtime.engines.base import (
    TIMING_DECIMALS, aggregate_generation_measurements, measurement_validation_errors,
)
from scripts.runtime.shared import Shared
from scripts.runtime.failure_handling import unexpected_model_failure
from scripts.runtime.crash_cache import check_crash_cache, load_crash_cache, record_crash
from scripts.runtime.progress_events import emit_model_finished, emit_progress
from scripts.runtime.pause_control import wait_if_paused


def conversation_failure_status(error, is_connection_crash) -> str:
    if isinstance(error, TimeoutError) or "timed out" in str(error).lower():
        return "timed_out"
    return "crashed" if is_connection_crash(error) else "failed"


class LLMConversationBenchmark:
    CONV_CRASH_CACHE = Path(".conv_crash_cache.json")

    CONV_NUM_SECTIONS = 6
    CONV_RUNS = 1   # too expensive to repeat --runs times like the other benchmarks

    CONV_TARGET_CTX = config.PREFILL_128K_TOKENS + 32768

    CONV_CHECKPOINTS = [
        0, 2048, 4096, 8192, 16384, 32768, 49152, 65536, 81920, 98304,
        config.PREFILL_128K_TOKENS,
    ]

    # See docs/workloads.md's conversation-test growth-step paragraph.
    CONV_STEP_MIN = 32
    CONV_STEP_MAX = 1024
    CONV_STEP_MAX_FAR = 4096
    CONV_STEP_DIVISOR = 4

    CONV_OPENING_PREDICT = 2048   # opening turn is a full structured answer, not a small growth step
    CONV_CTX_HEADROOM = 4096      # room beyond the top checkpoint so growth never scrapes num_ctx
    CONV_SAFETY_MARGIN = 64       # reserved so a non-final turn can't push the next one past num_ctx

    CONV_OPENING_PROMPT = (
        "Explain Plato's Allegory of the Cave in detail. Structure your answer into "
        f"{CONV_NUM_SECTIONS} numbered sections (Section 1 through Section {CONV_NUM_SECTIONS}): "
        "the setup and the prisoners, the escape and the ascent, the sun and the Form "
        "of the Good, the return to the cave, philosophical interpretation, and modern "
        "relevance. Write several detailed paragraphs for each section."
    )

    @staticmethod
    def compute_growth_step(cumulative_tokens: int, target: int, num_ctx: int,
                             is_last_checkpoint: bool) -> tuple[int | None, bool]:
        """num_predict for the next growth turn — see docs/workloads.md's
        conversation-test growth-step paragraph. Returns (step, out_of_room)."""
        remaining = target - cumulative_tokens
        step_max = (LLMConversationBenchmark.CONV_STEP_MAX_FAR
                    if remaining > 8192
                    else LLMConversationBenchmark.CONV_STEP_MAX)
        is_final_step = remaining <= step_max
        step = (remaining if is_final_step else
                max(LLMConversationBenchmark.CONV_STEP_MIN,
                    remaining // LLMConversationBenchmark.CONV_STEP_DIVISOR))
        step = max(LLMConversationBenchmark.CONV_STEP_MIN,
                   min(step_max, step))

        reserve = 0 if (is_last_checkpoint and is_final_step) \
            else LLMConversationBenchmark.CONV_SAFETY_MARGIN
        room = num_ctx - cumulative_tokens - reserve
        if room < LLMConversationBenchmark.CONV_STEP_MIN:
            return None, True
        return min(step, room), False

    @staticmethod
    def conv_ctx_plan(model_max: int, max_prompt_tokens: int | None = None) -> tuple[int, list[int], int]:
        """Resolve (target_ctx, checkpoints, num_ctx) from a model's real max
        context — every model gets the same plan, capped only by its own ceiling."""
        configured_target = min(LLMConversationBenchmark.CONV_TARGET_CTX,
                                max_prompt_tokens or LLMConversationBenchmark.CONV_TARGET_CTX)
        target_ctx = min(model_max, configured_target)
        checkpoints = Shared.supported_prompt_sizes(
            LLMConversationBenchmark.CONV_CHECKPOINTS, model_max,
        )
        checkpoints = [c for c in checkpoints if c <= target_ctx]
        num_ctx = Shared.ctx_with_headroom(target_ctx, LLMConversationBenchmark.CONV_CTX_HEADROOM, model_max)
        return target_ctx, checkpoints, num_ctx

    @staticmethod
    def should_stop_for_slow_measurement(measurement, force_all: bool) -> bool:
        return (not force_all and not measurement_validation_errors(measurement)
                and measurement.tokens_per_sec < config.SLOW_MODEL_MIN_TPS)

    @staticmethod
    def _conv_followup_prompt(section_n: int) -> str:
        section = ((section_n - 1) % LLMConversationBenchmark.CONV_NUM_SECTIONS) + 1
        return (
            f"Give much more detail about Section {section}, including additional "
            "examples, counterarguments, and analysis."
        )

    def run(self, engine, models, warmup_runs, force_all=False, save_fn=None,
            max_prompt_tokens=None, journal=None):  # pragma: no cover — orchestrates real engine runs
        results = journal.export() if journal else {}

        if not engine.ensure_running():
            Shared.err("Inference engine not reachable — skipping LLM conversation benchmarks")
            return results

        crash_cache = load_crash_cache(LLMConversationBenchmark.CONV_CRASH_CACHE)

        for model in models:
            tag   = model["tag"]
            label = model["label"]
            short = model["short"]

            Shared.section(f"LLM Conversation ({engine.name}): {label}")

            if not engine.reachable_or_abort():
                break

            emit_progress("model", "conv", "running", label, model_id=tag)
            try:
                if not engine.model_pulled(tag):
                    Shared.warn(f"{tag} not pulled — skipping")
                    Shared.warn("Download it with: python setup_check.py")
                    if journal:
                        journal.record_model_state(model, "skipped", {
                            "label": label, "skipped": True, "skip_reason": "not_installed",
                        })
                    continue

                skip_entry = check_crash_cache(
                    tag, label, crash_cache, LLMConversationBenchmark.CONV_CRASH_CACHE,
                    engine_name=engine.name,
                )
                if skip_entry is not None:
                    results[short] = skip_entry
                    if journal:
                        journal.record_model_state(model, "skipped", skip_entry)
                    continue

                model_max = engine.max_context_length(tag)
                target_ctx, checkpoints, num_ctx = LLMConversationBenchmark.conv_ctx_plan(
                    model_max, max_prompt_tokens,
                )
                top_checkpoint = checkpoints[-1] if checkpoints else 0

                Shared.log(f"{label}: model supports {model_max} ctx — num_ctx={num_ctx}, "
                           f"sampling up to {top_checkpoint} ({len(checkpoints)} checkpoints)")

                if journal and all(journal.next_context_attempt(model, target) is None for target in checkpoints):
                    continue
                Shared.verify_resume_model(journal, model, engine)
                if journal:
                    journal.begin_model_load()
                if not engine.warmup(tag, label, num_ctx, warmup_runs,
                                     crash_cache, LLMConversationBenchmark.CONV_CRASH_CACHE):
                    engine.unload(tag)
                    continue

                if journal:
                    journal.begin_measured()

                results[short] = {}
                # label -> list of (ttft, tps, depth_tokens), one entry per run that reached it
                samples_by_label = {}
                timed_out_label = None
                slow_label       = None
                crashed          = False
                crashed_label    = None

                for run_i in range(LLMConversationBenchmark.CONV_RUNS):
                    Shared.log(f"{label}: run {run_i+1}/{LLMConversationBenchmark.CONV_RUNS} — starting a fresh conversation ...")

                    messages                = []
                    cumulative_tokens       = 0
                    pending_response_tokens = 0
                    section_n               = 1
                    first_turn_done         = False
                    run_timed_out           = False
                    run_failed              = False
                    run_crashed             = False
                    active_case             = None

                    def _turn(prompt_text, num_predict):
                        nonlocal cumulative_tokens, pending_response_tokens
                        wait_if_paused()
                        messages.append({"role": "user", "content": prompt_text})
                        measurement = Shared.retry_implausible_tps(
                            lambda: engine.chat(
                                tag, messages, timeout=config.RUN_TIMEOUT, num_ctx=num_ctx,
                                num_predict=num_predict, cache_prompt=True,
                            ),
                            f"{tag} conversation turn",
                            "conv",
                        )
                        messages.append({"role": "assistant", "content": measurement.response_text})
                        # prompt_eval_count is ground truth for what's in context; eval_count isn't —
                        # a reasoning model's thinking content can get silently dropped from history next turn.
                        cumulative_tokens = measurement.prompt_tokens or 0
                        # Not yet in cumulative_tokens until next turn's prompt_eval_count — see docs/workloads.md.
                        pending_response_tokens = measurement.generated_tokens
                        return measurement

                    def _next_prompt():
                        nonlocal section_n, first_turn_done
                        if not first_turn_done:
                            first_turn_done = True
                            return LLMConversationBenchmark.CONV_OPENING_PROMPT
                        prompt_text = LLMConversationBenchmark._conv_followup_prompt(section_n)
                        section_n += 1
                        return prompt_text

                    try:
                        out_of_room = False
                        measurement = None
                        for idx, target in enumerate(checkpoints):
                            label_ctx = f"{target // 1024}K" if target > 0 else "0K"
                            attempt_number = journal.next_context_attempt(model, target) if journal else 1
                            active_case = (target, label_ctx, attempt_number)
                            if target == 0:
                                # Checkpoint 0 is just the opening turn — no growth to do first.
                                measurement = _turn(_next_prompt(),
                                                    LLMConversationBenchmark.CONV_OPENING_PREDICT)
                            else:
                                is_last_checkpoint = idx == len(checkpoints) - 1
                                Shared.log(f"{label}: run {run_i+1}/{LLMConversationBenchmark.CONV_RUNS} — growing toward "
                                           f"{label_ctx} (currently ~{cumulative_tokens} tokens) ...")

                                # Stop growing if we are within 0.5% of the target context length
                                target_threshold = int(target * 0.995)
                                while cumulative_tokens < target_threshold:
                                    step, ran_out = LLMConversationBenchmark.compute_growth_step(
                                        cumulative_tokens + pending_response_tokens, target_threshold,
                                        num_ctx, is_last_checkpoint)
                                    if ran_out:
                                        out_of_room = True
                                        break

                                    measurement = _turn(_next_prompt(), step)

                                if out_of_room:
                                    Shared.warn(f"{label}: run {run_i+1} ran out of context room "
                                                f"approaching {label_ctx} — stopping this run's growth here")
                                    break

                            # ttft/tps here are from the turn that just crossed `target`
                            # (or the opening turn for target == 0).
                            if measurement is None:
                                continue
                            if attempt_number is not None:
                                samples_by_label.setdefault(label_ctx, []).append(
                                    (measurement, cumulative_tokens))
                            if journal and attempt_number is not None:
                                journal.record_case(
                                    model, target, label_ctx, [measurement], "ok",
                                    LLMConversationBenchmark.CONV_RUNS,
                                    depth_tokens=cumulative_tokens,
                                    attempt_number=attempt_number,
                                )
                                active_case = None
                            elif journal:
                                Shared.log(f"Checkpoint {label_ctx} already complete — rebuilt cache only")
                            Shared.output(
                                f"    run {run_i+1}/{LLMConversationBenchmark.CONV_RUNS}: "
                                f"{label_ctx}  TTFT={measurement.client_ttft_sec:.2f}s  "
                                f"TPS={measurement.tokens_per_sec:.1f}  "
                                f"(depth~{cumulative_tokens})"
                            )

                            # See docs/workloads.md's within-conversation slow-model early exit.
                            if attempt_number is not None \
                                    and self.should_stop_for_slow_measurement(measurement, force_all):
                                Shared.warn(f"{label}: run {run_i+1} — {measurement.tokens_per_sec:.1f} tok/s at {label_ctx} is below "
                                            f"{config.SLOW_MODEL_MIN_TPS:.0f} tok/s cutoff — ending this run here")
                                slow_label = label_ctx
                                break

                    except Exception as e:
                        is_timeout = isinstance(e, TimeoutError) or "timed out" in str(e).lower()
                        if journal and active_case and active_case[2] is not None:
                            journal.record_case(
                                model, active_case[0], active_case[1], [],
                                conversation_failure_status(e, engine.is_connection_crash),
                                LLMConversationBenchmark.CONV_RUNS,
                                attempt_number=active_case[2],
                            )
                        if is_timeout:
                            Shared.err(f"{label}: run {run_i+1} timed out — stopping this run here")
                            partial_text = getattr(e, "partial_text", "")
                            if partial_text:
                                # Not scored (this test measures TTFT/TPS), just surfaced to tell a stall apart from a mid-stream cutoff.
                                Shared.warn(f"{label}: run {run_i+1} had streamed "
                                            f"{len(partial_text)} chars before the timeout: "
                                            f"{partial_text[:200]!r}")
                            run_timed_out = True
                            timed_out_label = timed_out_label or f"{cumulative_tokens // 1024}K"
                        elif engine.is_connection_crash(e):
                            # Mid-turn state makes retrying unsafe — stop the run, but wait for recovery before the next model.
                            Shared.err(f"{label}: run {run_i+1} — the engine's model runner appears to have crashed "
                                       f"— last server output:\n{engine.tail_log()}")
                            if not engine.wait_for_recovery():
                                Shared.warn("The engine did not become reachable again within 30s")
                            run_crashed = True
                            crashed_label = crashed_label or f"{cumulative_tokens // 1024}K"
                        else:
                            Shared.err(f"{label}: run {run_i+1} failed: {e}")
                            run_failed = True

                    if run_crashed:
                        crashed = True

                    if run_timed_out or run_failed or run_crashed:
                        Shared.warn(f"{label}: run {run_i+1} stopped early")

                for target in checkpoints:
                    label_ctx = f"{target // 1024}K"
                    samples = samples_by_label.get(label_ctx)
                    if not samples:
                        continue
                    aggregate = aggregate_generation_measurements(
                        [sample[0] for sample in samples], LLMConversationBenchmark.CONV_RUNS,
                    )
                    valid_samples = [s for s in samples
                                     if not measurement_validation_errors(s[0])]
                    measurements = [s[0] for s in valid_samples]
                    ttfts = [m.client_ttft_sec for m in measurements]
                    tpss = [m.tokens_per_sec for m in measurements]
                    depths = [s[1] for s in valid_samples]
                    if not valid_samples:
                        results[short][label_ctx] = aggregate
                        Shared.warn(f"{label}: {label_ctx} had no valid measurement")
                        continue
                    results[short][label_ctx] = {
                        "ttft_mean_sec":  round(Shared.mean(ttfts), TIMING_DECIMALS),
                        "ttft_stdev_sec": round(Shared.stdev(ttfts), TIMING_DECIMALS),
                        "tps_mean":       round(Shared.mean(tpss), 2),
                        "tps_stdev":      round(Shared.stdev(tpss), 2),
                        "ttft_runs":      [round(t, TIMING_DECIMALS) for t in ttfts],
                        "tps_runs":       [round(t, 2) for t in tpss],
                        "depth_tokens":   round(Shared.mean(depths)),
                        **aggregate,
                    }
                    Shared.ok(
                        f"{label_ctx} done ({len(samples)} run(s)): "
                        f"TTFT={results[short][label_ctx]['ttft_mean_sec']:.2f}s  "
                        f"TPS={results[short][label_ctx]['tps_mean']:.1f}"
                    )

                if timed_out_label:
                    results[short]["timed_out"] = timed_out_label
                    if journal:
                        journal.record_model_state(
                            model, "timed_out", {"timed_out": timed_out_label},
                        )
                if slow_label:
                    results[short]["slow_tps"] = slow_label
                    if journal:
                        journal.record_model_state(
                            model, "complete", {"slow_tps": slow_label},
                        )
                if crashed:
                    results[short]["crashed"] = crashed_label or "0K"
                    results[short]["crashed_at"] = record_crash(
                        tag, crash_cache, LLMConversationBenchmark.CONV_CRASH_CACHE, f"running {label}",
                        engine_name=engine.name)
                    if journal:
                        journal.record_model_state(model, "failed", {
                            "crashed": results[short]["crashed"],
                            "crashed_at": results[short]["crashed_at"],
                        })

                Shared.log(f"Unloading {label} ...")
                engine.unload(tag)
                engine.wait_until_unloaded(tag)
            except Exception as exc:
                Shared.err(f"{label}: unexpected error running the conversation benchmark — {exc} — "
                           "skipping remaining work for this model")
                entry = unexpected_model_failure(label, exc)
                results.setdefault(short, {}).update(entry)
                if journal:
                    journal.record_model_state(model, "failed", entry)
            finally:
                if save_fn:
                    save_fn(journal.export() if journal else results)
                emit_model_finished("conv", label, results.get(short), model_id=tag)

        if journal:
            journal.finish()
            return journal.export()
        return results
