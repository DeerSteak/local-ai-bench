import { FALLBACK_COLORS, EMBED_MODEL_ORDER, EMBED_BAR_COLORS } from "../constants";
import { embedModelLabel, entriesOf, lookup } from "./shared";
import { memoryFields } from "./memory";
import { powerFields } from "./power";
import type { BarConfig, ChartRow, ResultsFile } from "../types";

// Return all embedding model keys from the loaded files, in canonical order
export function getAllEmbedModels(files: ResultsFile[]): string[] {
  const s = new Set<string>();
  for (const f of files) for (const m of Object.keys(f.data.embeddings || {})) s.add(m);
  const known   = EMBED_MODEL_ORDER.filter(m => s.has(m));
  const unknown = [...s].filter(m => !EMBED_MODEL_ORDER.includes(m));
  return [...known, ...unknown];
}

export function getEmbedLabel(files: ResultsFile[], model: string): string {
  for (const f of files) {
    const d = f.data.embeddings?.[model];
    if (d?.label) return d.label;
  }
  return embedModelLabel(model);
}

// Embeddings bar chart: rows = files/systems, cols = models
export function buildEmbedGroupedBarData(files: ResultsFile[], enabledEmbedModels: Set<string>): ChartRow[] {
  const allModels = getAllEmbedModels(files).filter(m => enabledEmbedModels.has(m));
  return files
    .map(f => {
      const row: ChartRow = { systemLabel: f.hostname };
      for (const model of allModels) {
        const s = f.data.embeddings?.[model];
        if (s && !s.skipped) row[model] = s.chunks_per_sec_mean;
      }
      return row;
    })
    .filter(row => allModels.some(m => row[m] != null));
}

export function buildEmbedGroupedBarConfigs(files: ResultsFile[], enabledEmbedModels: Set<string>): BarConfig[] {
  const allModels = getAllEmbedModels(files).filter(m => enabledEmbedModels.has(m));
  return allModels.map((m, i) => ({
    dataKey: m,
    name: getEmbedLabel(files, m),
    fill: lookup(EMBED_BAR_COLORS, m) || FALLBACK_COLORS[i % FALLBACK_COLORS.length],
  }));
}

// Embeddings bar chart by system: rows = models, single throughput value, for one file
export function buildEmbedBarDataByModel(file: ResultsFile, models: string[]): { modelLabel: string, throughput?: number }[] {
  return models
    .map(model => {
      const s = file.data.embeddings?.[model];
      const row: { modelLabel: string, throughput?: number } = { modelLabel: getEmbedLabel([file], model) };
      if (s && !s.skipped) row.throughput = s.chunks_per_sec_mean;
      return row;
    })
    .filter(row => row.throughput != null);
}

export function buildEmbedBarConfigsByModel(file: ResultsFile, models: string[]): BarConfig[] {
  const hasAny = models.some(model => file.data.embeddings?.[model] && !file.data.embeddings[model].skipped);
  return hasAny ? [{ dataKey: "throughput", name: "Chunks/sec", fill: FALLBACK_COLORS[0] }] : [];
}

export function flattenEmbedData(files: ResultsFile[]): ChartRow[] {
  return files.flatMap(f =>
    entriesOf(f.data.embeddings).map(([model, s]) => {
      const modelLabel = s.label || model;
      if (s.skipped) {
        return {
          _fileId: f.id, model, modelLabel, skipped: true,
          skip_reason: s.skip_reason, skip_detail: s.skip_detail,
        };
      }
      return {
        _fileId: f.id, model, modelLabel,
        cps_mean: s.chunks_per_sec_mean,
        cps_stdev: s.chunks_per_sec_stdev,
        n_chunks: s.n_chunks,
        device: s.device,
        n_runs: s.valid_runs ?? s.n_runs,
        ...memoryFields(s),
        ...powerFields(s),
      };
    })
  );
}
