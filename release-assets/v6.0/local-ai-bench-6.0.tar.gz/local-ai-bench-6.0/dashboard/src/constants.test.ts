import { describe, it, expect } from "vitest";
import {
  LLM_MODEL_ORDER, LEGACY_LLM_MODEL_ORDER, LLM_DISPLAY_ORDER,
  LLM_MODEL_LABELS, MODEL_COLORS, MODEL_SIZE_TIER,
  IMAGE_MODEL_ORDER, LEGACY_IMAGE_MODEL_ORDER, IMAGE_DISPLAY_ORDER,
  IMAGE_MODEL_LABELS, IMAGE_MODEL_COLORS,
  EMBED_MODEL_ORDER, EMBED_MODEL_LABELS, EMBED_MODEL_COLORS,
  SIZE_TIER_ORDER, RES_ORDER, RES_COLORS, FALLBACK_COLORS,
  FILE_COLORS, CATEGORY_COLORS, CTX_COLORS, IMAGE_BAR_COLORS,
  EMBED_BAR_COLORS, BACKEND_COLORS, ACCURACY_TIMEOUT_BAR_CONFIGS,
  ACCURACY_TESTS, ACCURACY_TEST_LABELS, CTX_ORDER, SPEC_CARD_PREFERRED_CTX,
  MEMORY_CHANNEL_LABELS, MEMORY_HEADROOM_LABELS,
} from "./constants";
import { lookup } from "./utils/shared";

function relativeLuminance(hex: string): number {
  const channels = [1, 3, 5].map((offset) => {
    const channel = Number.parseInt(hex.slice(offset, offset + 2), 16) / 255;
    return channel <= 0.04045
      ? channel / 12.92
      : ((channel + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
}

function contrastAgainstWhite(hex: string): number {
  return 1.05 / (relativeLuminance(hex) + 0.05);
}

// These catch the most common maintenance mistake in this file: adding a
// model to one registry (e.g. LLM_MODEL_ORDER, to make it show up at all)
// without also adding it to the others (label, color, size tier) that other
// code assumes are present for every ordered model.
describe("model registry consistency", () => {
  it("contains every catalog quantization in base-model and tier order", () => {
    expect(LLM_MODEL_ORDER).toEqual([
      "gemma3-1b", "gemma3-1b-q6", "gemma3-1b-q8",
      "granite4.1-3b-q4", "granite4.1-3b-q6", "granite4.1-3b-q8",
      "qwen3.5-4b-q4", "qwen3.5-4b-q6", "qwen3.5-4b-q8",
      "granite4.1-8b-q4", "granite4.1-8b-q6", "granite4.1-8b-q8",
      "qwen3.5-9b-q4", "qwen3.5-9b-q6", "qwen3.5-9b-q8",
      "gemma4-12b-q4", "gemma4-12b-q6", "gemma4-12b-q8",
      "gemma4-26b-a4b-q4", "gemma4-26b-a4b-q6", "gemma4-26b-a4b-q8",
      "qwen3.8-27b-q4", "qwen3.8-27b-q6", "qwen3.8-27b-q8",
      "nemotron3.5-lightning-30b-a3b", "nemotron3.5-lightning-30b-a3b-q6",
      "nemotron3.5-lightning-30b-a3b-q8",
      "llama3.3-70b-q4", "llama3.3-70b-q6", "llama3.3-70b-q8",
      "qwen3-coder-next-80b-a3b-q4", "qwen3-coder-next-80b-a3b-q6",
      "qwen3-coder-next-80b-a3b-q8", "nemotron3-super-120b",
      "nemotron3-super-120b-q6", "nemotron3-super-120b-q8",
    ]);
  });

  it("every LLM model in LLM_MODEL_ORDER has a label, a color, and a valid size tier", () => {
    for (const model of LLM_MODEL_ORDER) {
      expect(lookup(LLM_MODEL_LABELS, model), `${model} missing a label`).toBeDefined();
      expect(lookup(MODEL_COLORS, model), `${model} missing a color`).toBeDefined();
      expect(lookup(MODEL_SIZE_TIER, model), `${model} missing a size tier`).toBeDefined();
      expect(SIZE_TIER_ORDER, `${model}'s tier "${lookup(MODEL_SIZE_TIER, model)}" is not a recognized tier`)
        .toContain(lookup(MODEL_SIZE_TIER, model));
    }
  });

  it("labels every cataloged quantization explicitly", () => {
    for (const model of LLM_MODEL_ORDER) {
      expect(lookup(LLM_MODEL_LABELS, model)).toMatch(/ — Q(4_K_M|6_K(?:_XL)?|8_0)$/);
    }
  });

  it("every image model in IMAGE_MODEL_ORDER has a label and a color", () => {
    for (const model of IMAGE_MODEL_ORDER) {
      expect(lookup(IMAGE_MODEL_LABELS, model), `${model} missing a label`).toBeDefined();
      expect(lookup(IMAGE_MODEL_COLORS, model), `${model} missing a color`).toBeDefined();
    }
  });

  it("keeps removed image models renderable after the current catalog", () => {
    expect(IMAGE_DISPLAY_ORDER).toEqual([...IMAGE_MODEL_ORDER, ...LEGACY_IMAGE_MODEL_ORDER]);
    expect(LEGACY_IMAGE_MODEL_ORDER).toEqual(["sd35-large"]);
    for (const model of LEGACY_IMAGE_MODEL_ORDER) {
      expect(lookup(IMAGE_MODEL_LABELS, model)).toBeDefined();
      expect(lookup(IMAGE_MODEL_COLORS, model)).toBeDefined();
    }
  });

  it("every embedding model in EMBED_MODEL_ORDER has a label and a color", () => {
    for (const model of EMBED_MODEL_ORDER) {
      expect(lookup(EMBED_MODEL_LABELS, model), `${model} missing a label`).toBeDefined();
      expect(lookup(EMBED_MODEL_COLORS, model), `${model} missing a color`).toBeDefined();
    }
  });

  it("LLM_MODEL_ORDER has no duplicate entries", () => {
    expect(new Set(LLM_MODEL_ORDER).size).toBe(LLM_MODEL_ORDER.length);
  });

  it("keeps removed catalog models renderable after the current catalog", () => {
    expect(LLM_DISPLAY_ORDER).toEqual([...LLM_MODEL_ORDER, ...LEGACY_LLM_MODEL_ORDER]);
    expect(new Set(LLM_DISPLAY_ORDER).size).toBe(LLM_DISPLAY_ORDER.length);
    for (const model of LEGACY_LLM_MODEL_ORDER) {
      expect(lookup(LLM_MODEL_LABELS, model)).toBeDefined();
      expect(lookup(MODEL_COLORS, model)).toBeDefined();
      expect(lookup(MODEL_SIZE_TIER, model)).toBeDefined();
    }
  });

  it("IMAGE_MODEL_ORDER and EMBED_MODEL_ORDER have no duplicate entries", () => {
    expect(new Set(IMAGE_MODEL_ORDER).size).toBe(IMAGE_MODEL_ORDER.length);
    expect(new Set(EMBED_MODEL_ORDER).size).toBe(EMBED_MODEL_ORDER.length);
  });
});

describe("image resolution registry", () => {
  it("includes SD 1.5 native resolutions before the larger-model defaults", () => {
    expect(RES_ORDER).toEqual(["512x512", "768x768", "1024x1024", "1536x1536"]);
  });

  it("assigns a color to every ordered resolution", () => {
    for (const resolution of RES_ORDER) expect(lookup(RES_COLORS, resolution)).toBeDefined();
  });
});

describe("accuracy registry", () => {
  it("matches the benchmark workload order and labels every test", () => {
    expect(ACCURACY_TESTS).toEqual(["mcq", "math", "reasoning", "code", "tool"]);
    for (const test of ACCURACY_TESTS) expect(lookup(ACCURACY_TEST_LABELS, test)).toBeTruthy();
  });
});

describe("context registry", () => {
  it("contains the preferred run-card checkpoint", () => {
    expect(CTX_ORDER).toContain(SPEC_CARD_PREFERRED_CTX);
  });
});

describe("memory telemetry registry", () => {
  it("labels every exported memory channel and availability state", () => {
    expect(Object.keys(MEMORY_CHANNEL_LABELS)).toEqual([
      "host_ram_used_gb", "process_rss_gb", "accelerator_memory_used_gb",
    ]);
    expect(Object.keys(MEMORY_HEADROOM_LABELS)).toEqual([
      "comfortable", "tight", "exceeded", "unknown", "not_recorded",
    ]);
  });
});

describe("dashboard color contrast", () => {
  it("keeps every foreground and data-series color WCAG AA compliant on white", () => {
    const colors = [
      ...Object.values(MODEL_COLORS),
      ...Object.values(IMAGE_MODEL_COLORS),
      ...Object.values(EMBED_MODEL_COLORS),
      ...FALLBACK_COLORS,
      ...FILE_COLORS,
      ...CATEGORY_COLORS,
      ...Object.values(CTX_COLORS),
      ...Object.values(IMAGE_BAR_COLORS),
      ...Object.values(EMBED_BAR_COLORS),
      ...Object.values(RES_COLORS),
      ...Object.values(BACKEND_COLORS).map(({ color }) => color),
      ...ACCURACY_TIMEOUT_BAR_CONFIGS.map(({ fill }) => fill),
    ];
    for (const color of colors) {
      expect(contrastAgainstWhite(color), `${color} has insufficient contrast`)
        .toBeGreaterThanOrEqual(4.5);
    }
  });
});
