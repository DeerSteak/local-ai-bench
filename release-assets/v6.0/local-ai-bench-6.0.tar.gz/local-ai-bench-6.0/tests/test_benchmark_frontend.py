import json
import ast
from pathlib import Path

import pytest

from scripts.app import benchmark_frontend
from scripts.runtime import config
from scripts.app.benchmark_frontend import (
    merge_model_inventories,
    models_runnable_by,
    parse_engine_selection,
    format_engine_selection,
    FRONTEND_STATE_VERSION,
    GUI_OPTION_DEFAULTS,
    LLM_BACKED_TESTS,
    FRONTEND_OPTION_CLASSIFICATION,
    FRONTEND_CONTROL_BINDINGS,
    FRONTEND_OPTION_INVENTORY,
    FrontendCancelled,
    MenuEntry,
    apply_test_shortcut,
    apply_saved_model_selection,
    apply_saved_test_selection,
    build_benchmark_command,
    build_model_entries,
    build_frontend_state,
    build_test_entries,
    choose_engine,
    choose_max_prompt_tokens,
    choose_models,
    choose_tests,
    choose_tg_tokens,
    load_frontend_state,
    missing_catalog_hint,
    model_selection_error,
    parse_toggle_numbers,
    render_model_menu,
    render_summary,
    frontend_option_gaps,
    frontend_state_availability_errors,
    frontend_state_from_run_plan,
    run_frontend,
    save_frontend_state,
    toggle_group,
    validate_gui_options,
)
from scripts.workloads.models import EMBED_MODELS, IMAGE_MODELS, LLM_MODELS
from scripts.workloads.model_variants import expanded_model_variants
from scripts.results.run_plan import RunPlan


class InputSequence:
    def __init__(self, values):
        self.values = iter(values)

    def __call__(self):
        value = next(self.values)
        if isinstance(value, BaseException):
            raise value
        return value


def test_frontend_inventory_classifies_every_public_benchmark_option():
    benchmark_path = Path(benchmark_frontend.__file__).with_name("benchmark.py")
    tree = ast.parse(benchmark_path.read_text(encoding="utf-8"))
    public_flags = {
        argument.value
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "add_argument"
        for argument in node.args
        if isinstance(argument, ast.Constant)
        and isinstance(argument.value, str)
        and argument.value.startswith("--")
    }
    assert set(FRONTEND_OPTION_INVENTORY) == public_flags
    assert all(status in {"exposed", "equivalent", "excluded", "missing"}
               and explanation for status, explanation in FRONTEND_OPTION_INVENTORY.values())


def test_frontend_inventory_exposes_the_remaining_configuration_work():
    assert frontend_option_gaps() == []


def test_every_exposed_option_is_bound_to_a_concrete_control():
    exposed = {
        flag for flag, (status, _) in FRONTEND_OPTION_INVENTORY.items()
        if status == "exposed"
    }
    assert set(FRONTEND_CONTROL_BINDINGS) == exposed
    assert len(set(FRONTEND_CONTROL_BINDINGS.values())) == len(FRONTEND_CONTROL_BINDINGS)


def test_frontend_gap_gate_can_report_declared_and_unbound_gaps():
    inventory = {
        "--ready": ("exposed", "Ready control"),
        "--unbound": ("exposed", "Missing control"),
        "--future": ("missing", "Not implemented"),
        "--internal": ("excluded", "Internal only"),
    }
    assert frontend_option_gaps(inventory, {"--ready": "ready_control"}) == [
        "--future", "--unbound",
    ]


def test_build_command_includes_execution_modes_when_selected():
    options = dict(
        GUI_OPTION_DEFAULTS, offline=True, gpu_split_mode="tensor",
        retry_crashed_models=True, llamacpp_no_repack=True, mtp="both",
    )
    command = build_benchmark_command(
        "llamacpp", Path("ComfyUI"), ["llm"],
        [MenuEntry("model", "Model", "llm", "LLM", True)], gui_options=options,
    )
    assert "--offline" in command
    assert "--retry-crashed-models" in command
    assert "--llamacpp-no-repack" in command
    assert command[command.index("--gpu-split-mode") + 1] == "tensor"
    assert command[command.index("--mtp") + 1] == "both"


def test_build_command_explicitly_disables_default_memory_telemetry():
    options = dict(GUI_OPTION_DEFAULTS, memory_telemetry=False)
    command = build_benchmark_command(
        "llamacpp", Path("ComfyUI"), ["llm"],
        [MenuEntry("model", "Model", "llm", "LLM", True)], gui_options=options,
    )
    assert "--no-memory-telemetry" in command


def test_variant_model_entries_default_to_only_the_catalog_default():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])

    entries = build_model_entries(inventory, ["llm"])

    assert [(entry.variant, entry.checked) for entry in entries] == [
        ("Q4_K_M", True), ("Q6_K", False), ("Q8_0", False),
    ]
    assert all("GB" in entry.label for entry in entries)


def test_large_variant_family_starts_entirely_unchecked():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[-1])

    entries = build_model_entries(inventory, ["llm"])

    assert not any(entry.checked for entry in entries)


def test_build_command_emits_checked_variant_sweep_and_base_model_selector():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])
    entries = build_model_entries(inventory, ["llm"])
    entries[1].checked = True
    entries[2].checked = True

    command = build_benchmark_command("llamacpp", Path("ComfyUI"), ["llm"], entries)

    llm_index = command.index("--llm-models")
    assert command[llm_index + 1] == "gemma3:1b-it-q4_K_M"
    assert [
        command[index + 1] for index, value in enumerate(command)
        if value == "--model-variant"
    ] == [
        "gemma3:1b-it=Q4_K_M", "gemma3:1b-it=Q6_K", "gemma3:1b-it=Q8_0",
    ]


def test_build_command_omits_variant_flag_for_default_only():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])
    entries = build_model_entries(inventory, ["llm"])

    command = build_benchmark_command("llamacpp", Path("ComfyUI"), ["llm"], entries)

    assert "--model-variant" not in command


def test_build_command_collapses_variant_sweep_when_vllm_is_selected():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])
    entries = build_model_entries(inventory, ["llm"])
    for entry in entries:
        entry.checked = True

    command = build_benchmark_command("llamacpp,vllm", Path("ComfyUI"), ["llm"], entries)

    assert "--model-variant" not in command
    llm_index = command.index("--llm-models")
    assert command[llm_index + 1:] == ["gemma3:1b-it-q4_K_M"]


def test_vllm_command_uses_default_when_only_nondefault_ggufs_are_listed():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])[1:]
    entries = build_model_entries(inventory, ["llm"])
    entries[0].checked = True

    command = build_benchmark_command("llamacpp,vllm", Path("ComfyUI"), ["llm"], entries)

    assert command[command.index("--llm-models") + 1:] == ["gemma3:1b-it-q4_K_M"]
    assert "--model-variant" not in command


def test_vllm_state_uses_default_when_only_nondefault_ggufs_are_listed():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0])[1:]
    entries = build_model_entries(inventory, ["llm"])
    entries[0].checked = True

    state = build_frontend_state("llamacpp,vllm", ["llm"], entries)

    assert state["models"]["llm"] == ["gemma3:1b-it-q4_K_M"]


def test_power_telemetry_is_exposed_and_requires_shared_memory_sampling():
    options = dict(GUI_OPTION_DEFAULTS, power_telemetry=True)
    assert validate_gui_options(options) == []
    command = build_benchmark_command(
        "llamacpp", Path("ComfyUI"), ["llm"],
        [MenuEntry("model", "Model", "llm", "LLM", True)], gui_options=options,
    )
    assert "--power-telemetry" in command
    assert validate_gui_options(dict(
        options, memory_telemetry=False,
    )) == ["Power telemetry requires memory telemetry."]


def test_frontend_classifies_every_option_for_ui_presentation():
    assert set(FRONTEND_OPTION_CLASSIFICATION) == set(FRONTEND_OPTION_INVENTORY)
    assert set(FRONTEND_OPTION_CLASSIFICATION.values()) <= {
        "guided", "advanced", "contextual", "developer-only", "unsafe", "unsupported",
    }
    assert FRONTEND_OPTION_CLASSIFICATION["--sample"] == "developer-only"


class FakeEngine:
    def __init__(self, name="fake"):
        self.name = name


@pytest.fixture(autouse=True)
def isolate_frontend_state(monkeypatch, tmp_path):
    monkeypatch.setattr(
        benchmark_frontend, "FRONTEND_STATE_PATH",
        tmp_path / ".benchmark_frontend_state.json",
    )


def sample_inventory():
    return {
        "llm": [LLM_MODELS[0], LLM_MODELS[-1]],
        "custom": [{
            "tag": "custom-folder",
            "label": "custom-folder (custom)",
            "short": "custom-folder",
            "size": 1,
        }],
        "embedding": list(EMBED_MODELS),
        "image": [IMAGE_MODELS[0], IMAGE_MODELS[-1]],
    }


def empty_inventory():
    return {"llm": [], "custom": [], "embedding": [], "image": []}


def full_inventory():
    inventory = sample_inventory()
    inventory["llm"] = list(LLM_MODELS)
    inventory["image"] = list(IMAGE_MODELS)
    return inventory


def output_collector():
    messages = []
    return messages, messages.append


def saved_state(**overrides):
    state = {
        "version": FRONTEND_STATE_VERSION,
        "engine": "fake",
        "tests": ["llm", "emb"],
        "models": {
            "llm": [LLM_MODELS[-1]["tag"], "custom-folder"],
            "embedding": [EMBED_MODELS[-1]["tag"]],
            "image": [],
        },
        "max_prompt_tokens": None,
        "tg_tokens": None,
    }
    state.update(overrides)
    return state


def test_frontend_state_round_trip_uses_strict_json(tmp_path):
    path = tmp_path / "state.json"
    state = saved_state()
    assert save_frontend_state(state, path)
    assert load_frontend_state(path) == state
    assert json.loads(path.read_text()) == state
    assert not list(tmp_path.glob(".*.tmp"))


def test_frontend_state_round_trip_preserves_optional_preset_selection(tmp_path):
    path = tmp_path / "state.json"
    state = saved_state(selected_preset="Quick run")
    assert save_frontend_state(state, path)
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["selected_preset"] == "Quick run"


def test_frontend_state_rejects_invalid_preset_selection(tmp_path):
    path = tmp_path / "state.json"
    path.write_text(json.dumps(saved_state(selected_preset="")), encoding="utf-8")
    assert load_frontend_state(path) is None


def test_saved_gui_state_defaults_legacy_missing_offline_to_false(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["offline"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["offline"] is False


def test_saved_gui_state_defaults_legacy_missing_memory_telemetry_to_true(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["memory_telemetry"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["memory_telemetry"] is True


def test_saved_gui_state_defaults_legacy_missing_gpu_split_to_layer(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["gpu_split_mode"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["gpu_split_mode"] == "layer"


def test_saved_gui_state_defaults_legacy_missing_mtp_to_off(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["mtp"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["mtp"] == "off"


def test_saved_gui_state_rejects_unknown_gpu_split_mode(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS, gpu_split_mode="row")
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    assert load_frontend_state(path) is None


def test_saved_gui_state_defaults_legacy_missing_retry_crashed_to_false(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["retry_crashed_models"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["retry_crashed_models"] is False


def test_saved_gui_state_defaults_legacy_missing_no_repack_to_false(tmp_path):
    path = tmp_path / "state.json"
    options = dict(GUI_OPTION_DEFAULTS)
    del options["llamacpp_no_repack"]
    path.write_text(json.dumps(saved_state(gui_options=options)), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["gui_options"]["llamacpp_no_repack"] is False


@pytest.mark.parametrize("contents", [
    "{",
    "[]",
    json.dumps({"version": FRONTEND_STATE_VERSION}),
    json.dumps(saved_state(version=999)),
    json.dumps(saved_state(engine=1)),
    json.dumps(saved_state(tests=[])),
    json.dumps(saved_state(tests=["llm", "llm"])),
    json.dumps(saved_state(models={"llm": [], "embedding": []})),
    json.dumps(saved_state(models={"llm": [1], "embedding": [], "image": []})),
    json.dumps(saved_state(max_prompt_tokens=0)),
    json.dumps(saved_state(max_prompt_tokens=-1)),
    json.dumps(saved_state(max_prompt_tokens="32768")),
    json.dumps(saved_state(tg_tokens=[128, 128])),
    json.dumps(saved_state(tg_tokens=[0])),
    json.dumps(saved_state(tg_tokens="128")),
])
def test_load_frontend_state_rejects_missing_or_malformed_state(tmp_path, contents):
    path = tmp_path / "state.json"
    path.write_text(contents)
    assert load_frontend_state(path) is None
    assert load_frontend_state(tmp_path / "missing.json") is None


def test_save_frontend_state_failure_cleans_temporary_file(tmp_path, monkeypatch):
    monkeypatch.setattr(benchmark_frontend, "atomic_write_json", lambda *args: (_ for _ in ()).throw(
        OSError("read only")))
    assert not save_frontend_state(saved_state(), tmp_path / "state.json")
    assert not list(tmp_path.glob(".*.tmp"))


def test_save_frontend_state_ignores_post_replace_cleanup_failure(tmp_path, monkeypatch):
    path = tmp_path / "state.json"
    real_unlink = Path.unlink

    def fail_only_for_moved_temporary(candidate, *args, **kwargs):
        if candidate.name.startswith(".state.json."):
            raise OSError("cleanup blocked")
        return real_unlink(candidate, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fail_only_for_moved_temporary)
    assert save_frontend_state(saved_state(), path)
    assert json.loads(path.read_text()) == saved_state()


def test_build_frontend_state_records_every_selected_family():
    entries = [
        MenuEntry("stock", "Stock", "llm", "LLM", True),
        MenuEntry("custom", "Custom", "custom", "Custom", True),
        MenuEntry("embed", "Embed", "embedding", "Embeddings", False),
        MenuEntry("image", "Image", "image", "Images", True),
    ]
    assert build_frontend_state("mlx", ["llm", "img"], entries) == {
        "version": FRONTEND_STATE_VERSION,
        "engine": "mlx",
        "tests": ["llm", "img"],
        "models": {
            "llm": ["stock", "custom"],
            "embedding": [],
            "image": ["image"],
        },
        "max_prompt_tokens": None,
        "tg_tokens": None,
    }


def test_build_frontend_state_records_max_prompt_tokens_and_tg_tokens():
    assert build_frontend_state(
        "mlx", ["llamabench"], [], max_prompt_tokens=32768, tg_tokens=[128, 1024],
    )["max_prompt_tokens"] == 32768
    assert build_frontend_state(
        "mlx", ["llamabench"], [], max_prompt_tokens=32768, tg_tokens=[128, 1024],
    )["tg_tokens"] == [128, 1024]


def test_build_frontend_state_records_gui_preset_when_provided():
    state = build_frontend_state(
        "mlx", ["llm"], [], selected_preset="Custom",
    )
    assert state["selected_preset"] == "Custom"


def test_cli_run_plan_converts_to_complete_frontend_state_and_command():
    plan = RunPlan.create(
        application_version="4.1", engine_name="llamacpp",
        tests=["llm", "emb", "img", "llamabench"],
        stage_order=["llm", "emb", "img", "llamabench"],
        models={
            "llm": [{"tag": "model:4b"}], "concurrency": [{"tag": "model:4b"}],
            "embeddings": [{"tag": "embed:latest"}], "images": [{"short": "sdxl"}],
        },
        effective_config={
            "runs": 4, "warmup_runs": 1, "run_timeout_seconds": 240,
            "accuracy_timeout_seconds": 45, "accuracy_token_budget": 1024,
            "cpu_only": True, "force_all": True, "retry_crashed_models": True,
            "max_prompt_tokens": 32768,
            "llamabench_tg": [128, 1024], "sample_size": None,
        },
    )
    local_options = {**benchmark_frontend.GUI_OPTION_DEFAULTS, "out": "/local/results.json"}
    state = frontend_state_from_run_plan(plan, local_options)
    assert state["models"] == {
        "llm": ["model:4b"], "embedding": ["embed:latest"], "image": ["sdxl"],
    }
    assert state["gui_options"]["out"] == "/local/results.json"
    entries = [
        MenuEntry("model:4b", "Model", "llm", "LLM", True),
        MenuEntry("embed:latest", "Embed", "embedding", "Embeddings", True),
        MenuEntry("sdxl", "Image", "image", "Images", True),
    ]
    command = build_benchmark_command(
        state["engine"], Path("/comfy"), state["tests"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
        max_prompt_tokens=state["max_prompt_tokens"], tg_tokens=state["tg_tokens"],
        gui_options=state["gui_options"],
    )
    for flag, value in (
        ("--runs", "4"), ("--warmup", "1"), ("--timeout", "240"),
        ("--acc-timeout", "45"), ("--acc-token-budget", "1024"),
        ("--max-prompt-tokens", "32768"),
    ):
        assert command[command.index(flag) + 1] == value
    assert "--cpu-only" in command and "--force-all" in command
    assert "--retry-crashed-models" in command
    assert command[command.index("--tg-tokens") + 1:command.index("--warmup")] == ["128", "1024"]


def test_cli_sample_plan_is_rejected_instead_of_silently_losing_value():
    plan = RunPlan.create(
        application_version="4.1", engine_name="llamacpp", tests=["mcq"],
        stage_order=["mcq"], models={"llm": [], "concurrency": [], "embeddings": [], "images": []},
        effective_config={"warmup_runs": 1, "cpu_only": False, "force_all": False,
                          "sample_size": 5},
    )
    with pytest.raises(ValueError, match="cannot be represented"):
        frontend_state_from_run_plan(plan)


def test_imported_state_reports_every_unavailable_selection():
    state = saved_state(
        engine="missing-engine", tests=["llm", "img"],
        models={"llm": ["missing-llm"], "embedding": [], "image": ["missing-image"]},
    )
    errors = frontend_state_availability_errors(
        state, ["llamacpp"],
        [MenuEntry("llm", "LLM", "llm", "Tests", True, available=True),
         MenuEntry("img", "Images", "image", "Tests", False, available=False)],
        [MenuEntry("installed", "Installed", "llm", "LLM", True)],
    )
    assert errors == [
        "Engine is not installed: missing-engine", "Tests are unavailable: img",
        "Models are not installed: missing-image, missing-llm",
    ]


def test_saved_test_selection_applies_only_available_remembered_tests():
    entries = build_test_entries(sample_inventory())
    entries_by_name = {entry.value: entry for entry in entries}
    entries_by_name["emb"].available = False
    assert apply_saved_test_selection(entries, saved_state(tests=["mcq", "emb"]))
    assert [entry.value for entry in entries if entry.checked] == ["mcq"]


def test_saved_test_selection_keeps_defaults_when_nothing_still_applies():
    entries = build_test_entries(sample_inventory())
    defaults = [entry.value for entry in entries if entry.checked]
    assert not apply_saved_test_selection(entries, saved_state(tests=["unknown"]))
    assert [entry.value for entry in entries if entry.checked] == defaults
    assert not apply_saved_test_selection(entries, None)


def test_saved_model_selection_restores_exact_installed_values_per_family():
    entries = build_model_entries(sample_inventory(), ["llm", "emb", "img"])
    apply_saved_model_selection(entries, saved_state())
    selected = {entry.value for entry in entries if entry.checked}
    assert selected == {
        LLM_MODELS[-1]["tag"], "custom-folder", EMBED_MODELS[-1]["tag"],
    }


def test_frontend_state_preserves_empty_generation_selection(tmp_path):
    path = tmp_path / "state.json"
    path.write_text(json.dumps(saved_state(tg_tokens=[])), encoding="utf-8")
    loaded = load_frontend_state(path)
    assert loaded is not None and loaded["tg_tokens"] == []


def test_saved_model_selection_keeps_family_defaults_when_all_values_are_stale():
    entries = build_model_entries(sample_inventory(), ["llm"])
    defaults = [entry.value for entry in entries if entry.checked]
    state = saved_state(models={
        "llm": ["removed-model"], "embedding": [], "image": [],
    })
    apply_saved_model_selection(entries, state)
    assert [entry.value for entry in entries if entry.checked] == defaults
    apply_saved_model_selection(entries, None)
    assert [entry.value for entry in entries if entry.checked] == defaults


def test_default_test_state_matches_documented_matrix():
    entries = {entry.value: entry for entry in build_test_entries(sample_inventory())}
    assert {name for name, entry in entries.items() if entry.checked} == {
        "llm", "conv", "emb", "img",
    }
    assert all(entries[name].available for name in entries)
    assert all(not entries[name].checked for name in (
        "mcq", "math", "reasoning", "code", "tool", "conc_tool", "conc_chat",
        "llamabench", "vllmbench",
    ))
    # llamabenchconc is folded into the llamabench toggle and is not its own entry.
    assert "llamabenchconc" not in entries


def test_vllm_bench_builds_llm_model_progress_rows():
    assert "vllmbench" in LLM_BACKED_TESTS


def test_empty_inventory_makes_every_test_unavailable_and_unchecked():
    entries = build_test_entries(empty_inventory())
    assert all(not entry.available and not entry.checked for entry in entries)


def test_family_specific_inventory_only_enables_its_tests():
    inventory = empty_inventory()
    inventory["embedding"] = [EMBED_MODELS[0]]
    entries = {entry.value: entry for entry in build_test_entries(inventory)}
    assert entries["emb"].available and entries["emb"].checked
    assert all(not entry.available for name, entry in entries.items() if name != "emb")


def test_model_defaults_select_nonlarge_catalog_and_embeddings_only():
    entries = build_model_entries(full_inventory(), ["llm", "emb", "img"])
    selected = {entry.value for entry in entries if entry.checked}
    assert {model["tag"] for model in LLM_MODELS if model["tier"] != "large"} <= selected
    assert not {model["tag"] for model in LLM_MODELS if model["tier"] == "large"} & selected
    assert "custom-folder" not in selected
    assert {model["tag"] for model in EMBED_MODELS} <= selected
    assert {model["short"] for model in IMAGE_MODELS if model["tier"] != "large"} <= selected
    assert not {model["short"] for model in IMAGE_MODELS if model["tier"] == "large"} & selected


def test_model_entries_only_include_families_used_by_selected_tests():
    llm_entries = build_model_entries(sample_inventory(), ["reasoning", "conc_chat"])
    assert {entry.kind for entry in llm_entries} == {"llm", "custom"}
    image_entries = build_model_entries(sample_inventory(), ["img"])
    assert {entry.kind for entry in image_entries} == {"image"}


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("2", {2}),
        ("2,4 6", {2, 4, 6}),
        ("3-5", {3, 4, 5}),
        ("2 4-5", {2, 4, 5}),
    ],
)
def test_parse_toggle_numbers(raw, expected):
    assert parse_toggle_numbers(raw, 6) == expected


@pytest.mark.parametrize("raw", ["", "0", "7", "4-2", "a", "2-x"])
def test_parse_toggle_numbers_rejects_invalid_input(raw):
    with pytest.raises(ValueError):
        parse_toggle_numbers(raw, 6)


def test_tier_toggle_spans_catalog_llm_and_images_but_not_custom_or_embedding():
    entries = [
        MenuEntry("llm", "LLM", "llm", "LLM", False, tier="small"),
        MenuEntry("image", "Image", "image", "Images", True, tier="small"),
        MenuEntry("custom", "Custom", "custom", "Custom", False),
        MenuEntry("embed", "Embed", "embedding", "Embeddings", False),
    ]
    assert toggle_group(
        entries, lambda entry: entry.kind in ("llm", "image") and entry.tier == "small",
    )
    assert entries[0].checked and entries[1].checked
    assert not entries[2].checked and not entries[3].checked
    toggle_group(entries, lambda entry: entry.kind in ("llm", "image") and entry.tier == "small")
    assert not entries[0].checked and not entries[1].checked


def test_group_toggle_reports_when_no_entries_match():
    assert not toggle_group([], lambda entry: True)


def test_test_shortcut_all_selects_every_available_test_only():
    entries = build_test_entries(sample_inventory())
    entries[3].available = False
    entries[3].checked = False
    assert apply_test_shortcut(entries, "a")
    assert all(entry.checked for entry in entries if entry.available)
    assert not entries[3].checked


@pytest.mark.parametrize(
    ("shortcut", "expected"),
    [
        ("l", {"llm", "conv", "llamabench", "vllmbench"}),
        ("x", {"mcq", "math", "reasoning", "code", "tool"}),
        ("c", {"conc_tool", "conc_chat"}),
        ("e", {"emb"}),
        ("i", {"img"}),
    ],
)
def test_test_shortcuts_toggle_workload_groups(shortcut, expected):
    entries = build_test_entries(sample_inventory())
    for entry in entries:
        entry.checked = False
    assert apply_test_shortcut(entries, shortcut)
    assert {entry.value for entry in entries if entry.checked} == expected
    assert apply_test_shortcut(entries, shortcut)
    assert not any(entry.checked for entry in entries)


def test_test_shortcut_rejects_unknown_or_unavailable_group():
    assert not apply_test_shortcut([], "x")
    assert not apply_test_shortcut(build_test_entries(sample_inventory()), "unknown")


def test_custom_and_embedding_bulk_toggles_are_independent():
    entries = [
        MenuEntry("c1", "C1", "custom", "Custom", False),
        MenuEntry("c2", "C2", "custom", "Custom", True),
        MenuEntry("e1", "E1", "embedding", "Embeddings", True),
    ]
    toggle_group(entries, lambda entry: entry.kind == "custom")
    assert entries[0].checked and entries[1].checked and entries[2].checked
    toggle_group(entries, lambda entry: entry.kind == "embedding")
    assert entries[0].checked and entries[1].checked and not entries[2].checked


def test_choose_engine_auto_selects_only_registered_engine():
    messages, output = output_collector()
    assert choose_engine(["llamacpp"], InputSequence([]), output) == "llamacpp"
    assert messages == ["Engine: llamacpp"]


def test_choose_engine_accepts_number_when_multiple_registered():
    messages, output = output_collector()
    selected = choose_engine(["llamacpp", "mlx"], InputSequence(["2"]), output)
    assert selected == "mlx"
    assert any("CLI-only" in message for message in messages)


def test_choose_engine_can_cancel():
    with pytest.raises(FrontendCancelled):
        choose_engine(["llamacpp", "mlx"], InputSequence(["q"]), lambda _: None)


def test_choose_engine_accepts_default_and_reprompts_after_invalid_input():
    messages, output = output_collector()
    assert choose_engine(
        ["llamacpp", "mlx"], InputSequence(["invalid", ""]), output,
    ) == "llamacpp"
    assert any("Couldn't parse" in message for message in messages)


def test_choose_engine_preserves_first_render_then_clears_each_redraw():
    clears = []
    assert choose_engine(
        ["llamacpp", "mlx"], InputSequence(["invalid", ""]), lambda _: None,
        clear_fn=lambda: clears.append(True),
    ) == "llamacpp"
    assert len(clears) == 1


def test_choose_tests_toggles_individual_entries_and_rejects_unavailable():
    entries = build_test_entries(sample_inventory())
    positions = {entry.value: i for i, entry in enumerate(entries, 1)}
    emb = next(entry for entry in entries if entry.value == "emb")
    emb.available = False
    emb.checked = False
    messages, output = output_collector()
    selected = choose_tests(
        entries, InputSequence([str(positions["mcq"]), str(positions["emb"]), ""]), output,
    )
    assert "mcq" in selected
    assert "emb" not in selected
    assert any("cannot be selected" in message for message in messages)


def test_choose_tests_accepts_shortcuts_and_renders_legend():
    entries = build_test_entries(sample_inventory())
    for entry in entries:
        entry.checked = False
    messages, output = output_collector()
    selected = choose_tests(entries, InputSequence(["x", "c", ""]), output)
    assert selected == [
        "mcq", "math", "reasoning", "code", "tool", "conc_tool", "conc_chat",
    ]
    assert any("a all" in message and "x accuracy" in message for message in messages)


def test_choose_tests_reprompts_when_everything_is_deselected():
    entries = build_test_entries(sample_inventory())
    messages, output = output_collector()
    # Toggle off exactly the default-checked entries by position, so inserting a new
    # default-off test elsewhere in TEST_DEFINITIONS does not shift this selection.
    checked = " ".join(str(i) for i, e in enumerate(entries, 1) if e.checked)
    selected = choose_tests(entries, InputSequence([checked, "", "1", ""]), output)
    assert selected == ["llm"]
    assert any("Select at least one" in message for message in messages)


def test_choose_tests_eof_cancels():
    with pytest.raises(FrontendCancelled):
        choose_tests(build_test_entries(sample_inventory()), InputSequence([EOFError()]), lambda _: None)


def test_choose_tests_q_cancels_and_invalid_input_reprompts():
    entries = build_test_entries(sample_inventory())
    messages, output = output_collector()
    with pytest.raises(FrontendCancelled):
        choose_tests(entries, InputSequence(["invalid", "q"]), output)
    assert any("Couldn't parse" in message for message in messages)


def test_choose_tests_clears_each_redraw_and_keeps_feedback_visible():
    entries = build_test_entries(sample_inventory())
    messages, output = output_collector()
    clears = []
    selected = choose_tests(
        entries, InputSequence(["invalid", ""]), output,
        clear_fn=lambda: clears.append(len(messages)),
    )
    assert selected == ["llm", "conv", "emb", "img"]
    assert len(clears) == 1
    second_menu = messages[clears[0]:]
    assert "Couldn't parse that selection; use numbers/ranges or a shortcut from the legend." in second_menu


def test_choose_models_tier_partial_to_all_then_all_to_none():
    entries = build_model_entries(sample_inventory(), ["llm", "img"])
    small_tier = [entry for entry in entries if entry.tier == LLM_MODELS[0]["tier"]]
    assert small_tier and all(entry.checked for entry in small_tier)
    messages, output = output_collector()
    choose_models(entries, ["llm", "img"], None, InputSequence(["xs", "xs", ""]), output)
    assert all(entry.checked for entry in small_tier)
    assert any("Tier keys" in message for message in messages)


def test_choose_models_custom_and_embedding_commands():
    entries = build_model_entries(sample_inventory(), ["llm", "emb"])
    choose_models(entries, ["llm", "emb"], None, InputSequence(["custom", "emb", "emb", ""]), lambda _: None)
    assert all(entry.checked for entry in entries if entry.kind == "custom")
    assert all(entry.checked for entry in entries if entry.kind == "embedding")


def test_choose_models_reprompts_when_required_family_is_empty():
    entries = build_model_entries(sample_inventory(), ["img"])
    messages, output = output_collector()
    choose_models(entries, ["img"], None, InputSequence(["1", "", "1", ""]), output)
    assert any("Select at least one image" in message for message in messages)


def test_choose_models_handles_unavailable_groups_invalid_input_and_cancel():
    entries = [MenuEntry("llm", "LLM", "llm", "LLM", True, tier="small")]
    messages, output = output_collector()
    with pytest.raises(FrontendCancelled):
        choose_models(
            entries, ["llm"], None,
            InputSequence(["l", "custom", "invalid", "q"]), output,
        )
    assert any("tier large" in message for message in messages)
    assert any("custom models" in message for message in messages)
    assert any("Couldn't parse" in message for message in messages)


def test_choose_models_clears_each_redraw_and_keeps_feedback_visible():
    entries = build_model_entries(sample_inventory(), ["llm"])
    messages, output = output_collector()
    clears = []
    choose_models(
        entries, ["llm"], None, InputSequence(["invalid", ""]), output,
        clear_fn=lambda: clears.append(len(messages)),
    )
    assert len(clears) == 1
    second_menu = messages[clears[0]:]
    assert any("Couldn't parse" in message for message in second_menu)


def test_model_selection_error_covers_each_required_family():
    llm_error = model_selection_error([], ["conv"])
    embedding_error = model_selection_error([], ["emb"])
    image_error = model_selection_error([], ["img"])
    assert llm_error is not None and "LLM" in llm_error
    assert embedding_error is not None and "embedding" in embedding_error
    assert image_error is not None and "image" in image_error
    assert model_selection_error(
        [MenuEntry("x", "X", "custom", "Custom", True)], ["tool", "conc_chat"],
    ) is None


def test_render_model_menu_has_one_shared_llm_list_and_cross_family_help():
    entries = build_model_entries(sample_inventory(), ["llm", "conv", "mcq", "conc_tool", "img"])
    messages, output = output_collector()
    render_model_menu(entries, "missing hint", output)
    assert sum("LLM —" in message for message in messages) == 2
    assert any("catalog LLM and image models together" in message for message in messages)
    assert messages[-1] == "missing hint"


def test_missing_catalog_hint_counts_families_and_ignores_custom_models():
    inventory = sample_inventory()
    hint = missing_catalog_hint(inventory, "Linux")
    assert hint is not None
    assert f"{len(LLM_MODELS) - 2} LLM" in hint
    assert f"{len(IMAGE_MODELS) - 2} image" in hint
    assert "custom" not in hint
    assert "`bash setup.sh`" in hint


def test_missing_catalog_hint_uses_windows_command():
    windows_hint = missing_catalog_hint(empty_inventory(), "Windows")
    assert windows_hint is not None and "`setup.bat`" in windows_hint


def test_missing_catalog_hint_omitted_when_every_catalog_model_installed():
    inventory = {
        "llm": list(LLM_MODELS), "custom": [],
        "embedding": list(EMBED_MODELS), "image": list(IMAGE_MODELS),
    }
    assert missing_catalog_hint(inventory, "Linux") is None


def test_missing_catalog_hint_counts_variant_families_without_negative_values():
    inventory = empty_inventory()
    inventory["llm"] = expanded_model_variants(LLM_MODELS[0]) * 8

    hint = missing_catalog_hint(inventory, "Linux")

    assert hint is not None
    assert f"{len(LLM_MODELS) - 1} LLM" in hint
    assert "-" not in hint.split("LLM", 1)[0]


def test_build_command_emits_every_applicable_explicit_selector(tmp_path):
    entries = build_model_entries(sample_inventory(), ["llm", "emb", "img"])
    command = build_benchmark_command(
        "fake", tmp_path / "Comfy UI", ["llm", "emb", "img"], entries,
        python_executable="python-test", benchmark_path=Path("/repo/custom/benchmark.py"),
    )
    assert command[:8] == [
        "python-test", "/repo/custom/benchmark.py", "--engine", "fake",
        "--comfyui", str(tmp_path / "Comfy UI"), "--tests", "llm",
    ]
    assert "--llm-models" in command
    assert "--embedding-models" in command
    assert "--image-models" in command
    assert "--maxtier" not in command


@pytest.mark.parametrize(
    ("tests", "entry", "selector"),
    [
        (["llm"], MenuEntry("phi4-mini", "Phi", "llm", "LLM", True), "--llm-models"),
        (["emb"], MenuEntry("nomic-embed-text", "Nomic", "embedding", "Embeddings", True),
         "--embedding-models"),
        (["img"], MenuEntry("sdxl", "SDXL", "image", "Images", True), "--image-models"),
    ],
)
def test_build_command_is_exact_for_each_isolated_workload_family(tests, entry, selector):
    comfyui = ["--comfyui", str(Path("/comfy"))] if "img" in tests else []
    assert build_benchmark_command(
        "fake", Path("/comfy"), tests, [entry],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    ) == [
        "python", "/benchmark.py", "--engine", "fake", *comfyui,
        "--tests", *tests, selector, entry.value,
    ]


def test_build_command_omits_comfyui_when_no_image_test_is_selected():
    # A ComfyUI that was never installed fails --comfyui validation and aborts the run.
    for tests in (["llm"], ["emb"], ["llm", "conv", "acc"]):
        assert "--comfyui" not in build_benchmark_command(
            "fake", Path("/not/installed"), tests,
            [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
            python_executable="python", benchmark_path=Path("/benchmark.py"),
        )


def test_build_command_keeps_an_explicit_gui_comfyui_path_only_for_image_runs():
    options = dict(GUI_OPTION_DEFAULTS, comfyui="/chosen/ComfyUI")
    entries = [MenuEntry("sdxl", "SDXL", "image", "Images", True)]
    with_images = build_benchmark_command(
        "fake", Path("/comfy"), ["img"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
        gui_options=options,
    )
    assert with_images[with_images.index("--comfyui") + 1] == "/chosen/ComfyUI"

    without_images = build_benchmark_command(
        "fake", Path("/comfy"), ["llm"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
        gui_options=options,
    )
    assert "--comfyui" not in without_images
    assert "/chosen/ComfyUI" not in without_images


def test_build_command_uses_one_llm_selection_for_accuracy_and_concurrency():
    entries = [
        MenuEntry("phi4-mini", "Phi", "llm", "LLM", True),
        MenuEntry("custom-one", "Custom", "custom", "Custom", True),
    ]
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["reasoning", "conc_chat"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    index = command.index("--llm-models")
    assert command[index + 1:] == ["phi4-mini", "custom-one"]
    assert command.count("--llm-models") == 1


def test_build_command_standalone_conversation_has_no_other_model_flags():
    entries = [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)]
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["conv"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    assert "--llm-models" in command
    assert "--embedding-models" not in command
    assert "--image-models" not in command


def test_build_command_treats_llamabench_as_llm_backed():
    entries = [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)]
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llamabench"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    assert "--llm-models" in command
    assert "--embedding-models" not in command
    assert "--image-models" not in command


def test_build_command_treats_llamabenchconc_as_llm_backed():
    entries = [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)]
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llamabenchconc"], entries,
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    assert "--llm-models" in command
    assert "--embedding-models" not in command
    assert "--image-models" not in command


def test_build_command_uses_default_benchmark_path():
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llm"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python",
    )
    assert command[:3] == ["python", "-m", "scripts.app.benchmark"]


def test_build_command_omits_max_prompt_tokens_by_default():
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llm"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    assert "--max-prompt-tokens" not in command


def test_build_command_includes_max_prompt_tokens_when_set():
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llamabench"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
        max_prompt_tokens=32768,
    )
    index = command.index("--max-prompt-tokens")
    assert command[index + 1] == "32768"


def test_choose_max_prompt_tokens_returns_none_on_blank_input():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(InputSequence([""]), output) is None


def test_choose_max_prompt_tokens_returns_none_for_the_no_cap_option():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(InputSequence(["0"]), output, options=[512, 2048]) is None


def test_choose_max_prompt_tokens_selects_the_numbered_option():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(
        InputSequence(["3"]), output, options=[512, 2048, 8192, 32768],
    ) == 8192


def test_choose_max_prompt_tokens_blank_input_accepts_the_restored_preference():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(
        InputSequence([""]), output, options=[512, 2048, 8192], preferred=2048,
    ) == 2048
    assert any("2048 (restored)" in message for message in messages)


def test_choose_max_prompt_tokens_explicit_zero_overrides_a_restored_preference():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(
        InputSequence(["0"]), output, options=[512, 2048, 8192], preferred=2048,
    ) is None


def test_choose_max_prompt_tokens_cancels_on_q():
    with pytest.raises(FrontendCancelled):
        choose_max_prompt_tokens(InputSequence(["q"]), lambda _: None)


def test_choose_max_prompt_tokens_reprompts_on_invalid_input():
    messages, output = output_collector()
    assert choose_max_prompt_tokens(
        InputSequence(["not-a-number", "99", "2"]), output, options=[512, 2048, 8192],
    ) == 2048
    assert any("Couldn't parse that selection" in message for message in messages)


def test_choose_max_prompt_tokens_lists_the_default_option_set():
    messages, output = output_collector()
    choose_max_prompt_tokens(InputSequence(["0"]), output)
    assert any(str(config.LLAMABENCH_PP[-1]) in message for message in messages)
    assert any(str(config.CONTEXT_LENGTHS[0]) in message for message in messages)


def test_render_summary_includes_max_prompt_tokens_when_set():
    messages, output = output_collector()
    render_summary("fake", Path("/comfy"), ["llm"], [], output, max_prompt_tokens=32768)
    assert any("32768" in message for message in messages)


def test_render_summary_omits_max_prompt_tokens_line_by_default():
    messages, output = output_collector()
    render_summary("fake", Path("/comfy"), ["llm"], [], output)
    assert not any("Max prompt" in message for message in messages)


def test_build_command_omits_tg_tokens_by_default():
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llamabench"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
    )
    assert "--tg-tokens" not in command


def test_build_command_includes_tg_tokens_when_set():
    command = build_benchmark_command(
        "fake", Path("/comfy"), ["llamabenchconc"],
        [MenuEntry("phi4-mini", "Phi", "llm", "LLM", True)],
        python_executable="python", benchmark_path=Path("/benchmark.py"),
        tg_tokens=[128, 1024],
    )
    index = command.index("--tg-tokens")
    assert command[index + 1:index + 3] == ["128", "1024"]


def test_choose_tg_tokens_accepts_the_defaults_on_blank_input():
    messages, output = output_collector()
    assert choose_tg_tokens(
        InputSequence([""]), output, options=[128, 512, 1024], default_checked={128, 512},
    ) == [128, 512]


def test_choose_tg_tokens_toggles_entries():
    messages, output = output_collector()
    assert choose_tg_tokens(
        InputSequence(["3", ""]), output, options=[128, 512, 1024], default_checked={128, 512},
    ) == [128, 512, 1024]


def test_choose_tg_tokens_cancels_on_q():
    with pytest.raises(FrontendCancelled):
        choose_tg_tokens(InputSequence(["q"]), lambda _: None)


def test_choose_tg_tokens_reprompts_when_everything_is_deselected():
    messages, output = output_collector()
    result = choose_tg_tokens(
        InputSequence(["1 2", "", "1", ""]), output, options=[128, 512], default_checked={128, 512},
    )
    assert result == [128]
    assert any("Select at least one generation size" in message for message in messages)


def test_choose_tg_tokens_reprompts_on_invalid_input():
    messages, output = output_collector()
    result = choose_tg_tokens(
        InputSequence(["invalid", ""]), output, options=[128, 512], default_checked={128},
    )
    assert result == [128]
    assert any("Couldn't parse that selection" in message for message in messages)


def test_render_summary_includes_tg_tokens_when_set():
    messages, output = output_collector()
    render_summary("fake", Path("/comfy"), ["llamabench"], [], output, tg_tokens=[128, 1024])
    assert any("128, 1024" in message for message in messages)


def test_render_summary_omits_tg_tokens_line_by_default():
    messages, output = output_collector()
    render_summary("fake", Path("/comfy"), ["llamabench"], [], output)
    assert not any("Generation (tg)" in message for message in messages)


def test_run_frontend_launches_argument_list_and_propagates_exit_code(tmp_path):
    commands = []
    messages, output = output_collector()

    class Result:
        returncode = 7

    result = run_frontend(
        input_fn=InputSequence(["", "", "", ""]),
        output_fn=output,
        process_runner=lambda command: commands.append(command) or Result(),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        system="Linux",
        python_executable="python-test",
        benchmark_path=tmp_path / "benchmark.py",
    )
    assert result == 7
    assert len(commands) == 1
    assert commands[0][0] == "python-test"
    assert str(config.COMFYUI_DIR) in commands[0]
    assert any("Launching benchmark.py" in message for message in messages)
    assert "Start this benchmark? [Y/n]" in messages
    state = load_frontend_state(tmp_path / ".benchmark_frontend_state.json")
    assert state is not None
    assert state["engine"] == "fake"
    assert state["tests"] == ["llm", "conv", "emb", "img"]


def test_run_frontend_default_output_function_is_untimestamped(capsys):
    result = run_frontend(
        input_fn=InputSequence(["", "", "", "y"]),
        process_runner=lambda command: 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
    )
    lines = capsys.readouterr().out.splitlines()
    assert result == 0
    assert lines
    assert all(not line.startswith("[") for line in lines)


def test_run_frontend_keeps_model_selection_visible_for_confirmation():
    clears = []
    result = run_frontend(
        input_fn=InputSequence(["", "", "", ""]),
        output_fn=lambda _: None,
        process_runner=lambda command: 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: clears.append(True),
    )
    assert result == 0
    assert len(clears) == 3


def test_run_frontend_banner_survives_until_single_engine_test_menu():
    visible = []

    def clear():
        visible.clear()

    result = run_frontend(
        input_fn=InputSequence(["q"]),
        output_fn=visible.append,
        process_runner=lambda command: pytest.fail("cancel must not launch"),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=clear,
    )
    assert result == 0
    assert visible[:3] == [
        "Local AI Bench interactive launcher",
        "Engine: fake",
        "Choose benchmark tests:",
    ]


def test_run_frontend_marks_restored_selections_and_explains_reset(tmp_path):
    state_path = tmp_path / "remembered.json"
    assert save_frontend_state(saved_state(), state_path)
    visible = []

    result = run_frontend(
        input_fn=InputSequence(["q"]),
        output_fn=visible.append,
        process_runner=lambda command: pytest.fail("cancel must not launch"),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        state_path=state_path,
    )
    assert result == 0
    assert any(
        "Restored saved selections" in message
        and "`remembered.json`" in message
        and "delete this file to reset" in message
        for message in visible
    )


def test_run_frontend_restores_saved_tests_models_and_engine(tmp_path):
    state_path = tmp_path / "state.json"
    state = saved_state(
        engine="mlx",
        tests=["reasoning"],
        models={
            "llm": [LLM_MODELS[-1]["tag"], "custom-folder"],
            "embedding": [],
            "image": [],
        },
    )
    assert save_frontend_state(state, state_path)
    commands = []

    result = run_frontend(
        input_fn=InputSequence(["", "", "", ""]),
        output_fn=lambda _: None,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["llamacpp", "mlx"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        state_path=state_path,
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )

    assert result == 0
    command = commands[0]
    assert command[command.index("--engine") + 1] == "mlx"
    tests_index = command.index("--tests")
    assert command[tests_index + 1:command.index("--llm-models")] == ["reasoning"]
    assert command[command.index("--llm-models") + 1:] == [
        LLM_MODELS[-1]["tag"], "custom-folder",
    ]


def test_run_frontend_restores_max_prompt_tokens_and_tg_tokens(tmp_path):
    state_path = tmp_path / "state.json"
    state = saved_state(
        tests=["llamabench"],
        models={
            "llm": [LLM_MODELS[-1]["tag"], "custom-folder"],
            "embedding": [],
            "image": [],
        },
        max_prompt_tokens=16384,
        tg_tokens=[128, 1024],
    )
    assert save_frontend_state(state, state_path)
    commands = []

    result = run_frontend(
        input_fn=InputSequence(["", "", "", "", ""]),
        output_fn=lambda _: None,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        state_path=state_path,
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )

    assert result == 0
    command = commands[0]
    index = command.index("--max-prompt-tokens")
    assert command[index + 1] == "16384"
    index = command.index("--tg-tokens")
    assert command[index + 1:index + 3] == ["128", "1024"]

    restored_state = load_frontend_state(state_path)
    assert restored_state is not None
    assert restored_state["max_prompt_tokens"] == 16384
    assert restored_state["tg_tokens"] == [128, 1024]


def test_run_frontend_skips_max_prompt_tokens_prompt_for_unrelated_tests():
    state_path_unused = None
    commands = []
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence(["1 2 8", "", "", ""]),
        output_fn=output,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )
    assert result == 0
    assert "--max-prompt-tokens" not in commands[0]
    assert not any("Cap the max prompt-processing size" in message for message in messages)


def test_run_frontend_prompts_for_max_prompt_tokens_when_llamabench_selected():
    commands = []
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence(["1 2 3 4 13", "", "", "5", "", ""]),
        output_fn=output,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )
    assert result == 0
    assert any("Cap the max prompt-processing size" in message for message in messages)
    index = commands[0].index("--max-prompt-tokens")
    assert commands[0][index + 1] == "16384"
    assert any("Choose generation (tg) sizes" in message for message in messages)
    assert commands[0][commands[0].index("--tg-tokens") + 1:commands[0].index("--llm-models")] == ["128", "512"]


@pytest.mark.parametrize("test_toggles", ["2 4 13", "1 4 13"])
def test_run_frontend_applies_max_prompt_tokens_to_llm_and_conversation(test_toggles):
    commands = []
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence([test_toggles, "", "", "5", ""]),
        output_fn=output,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )
    assert result == 0
    assert any("Cap the max prompt-processing size" in message for message in messages)
    index = commands[0].index("--max-prompt-tokens")
    assert commands[0][index + 1] == "16384"


def test_run_frontend_cancel_does_not_create_state_file(tmp_path):
    state_path = tmp_path / "state.json"
    result = run_frontend(
        input_fn=InputSequence(["", "", "", "n"]),
        output_fn=lambda _: None,
        process_runner=lambda command: pytest.fail("cancel must not launch"),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        state_path=state_path,
    )
    assert result == 0
    assert not state_path.exists()


def test_run_frontend_state_write_failure_warns_but_still_launches(
        tmp_path, monkeypatch):
    monkeypatch.setattr(benchmark_frontend, "save_frontend_state", lambda *args: False)
    messages, output = output_collector()
    called = []
    result = run_frontend(
        input_fn=InputSequence(["", "", "", ""]),
        output_fn=output,
        process_runner=lambda command: called.append(command) or 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
        clear_fn=lambda: None,
        state_path=tmp_path / "state.json",
    )
    assert result == 0
    assert called
    assert any("continuing without persistence" in message for message in messages)


def test_run_frontend_uses_selected_engine_and_setup_comfyui_path():
    commands = []
    seen = []
    result = run_frontend(
        input_fn=InputSequence(["2", "", "", "", "y"]),
        output_fn=lambda _: None,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["llamacpp", "mlx"],
        engine_factory=lambda name: FakeEngine(name),
        inventory_builder=lambda engine, path: seen.append((engine.name, path)) or sample_inventory(),
        system="Windows",
        python_executable="python",
        benchmark_path=Path("/benchmark.py"),
    )
    assert result == 0
    assert seen == [("mlx", config.COMFYUI_MODELS_DIR)]
    assert commands[0][commands[0].index("--engine") + 1] == "mlx"
    assert commands[0][commands[0].index("--comfyui") + 1] == str(config.COMFYUI_DIR)


def test_run_frontend_shows_tests_without_a_path_prompt():
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence(["q"]),
        output_fn=output,
        process_runner=lambda command: 0,
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
    )
    assert result == 0
    assert any(message == "Choose benchmark tests:" for message in messages)
    assert not any(message.startswith("ComfyUI directory [") for message in messages)


def test_run_frontend_explicit_no_cancels_final_confirmation():
    called = []
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence(["", "", "", "n"]),
        output_fn=output,
        process_runner=lambda command: called.append(command),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: sample_inventory(),
    )
    assert result == 0
    assert called == []
    assert messages[-1] == "Benchmark selection cancelled."


def test_run_frontend_launches_vllm_without_qualification_messaging():
    commands = []
    messages, output = output_collector()
    result = run_frontend(
        input_fn=InputSequence(["", "", "", ""]), output_fn=output,
        process_runner=lambda command: commands.append(command) or 0,
        engine_names_fn=lambda: ["vllm"], engine_factory=FakeEngine,
        inventory_builder=lambda _engine, _path: sample_inventory(),
    )
    assert result == 0
    assert "--ack-experimental-engine" not in commands[0]
    assert not any("qualification" in message.lower() for message in messages)


def test_run_frontend_q_eof_or_interrupt_cancels_without_process():
    for first_input in ("q", EOFError(), KeyboardInterrupt()):
        called = []
        result = run_frontend(
            input_fn=InputSequence([first_input]),
            output_fn=lambda _: None,
            process_runner=lambda command: called.append(command),
            engine_names_fn=lambda: ["fake"],
            engine_factory=FakeEngine,
            inventory_builder=lambda engine, path: sample_inventory(),
        )
        assert result == 0
        assert called == []


def test_run_frontend_returns_error_without_any_installed_models():
    called = []
    result = run_frontend(
        input_fn=InputSequence([]),
        output_fn=lambda _: None,
        process_runner=lambda command: called.append(command),
        engine_names_fn=lambda: ["fake"],
        engine_factory=FakeEngine,
        inventory_builder=lambda engine, path: empty_inventory(),
    )
    assert result == 1
    assert called == []


# ── multi-engine model inventories ──

def _inventory(llm_tags, image_shorts=()):
    return {
        "llm": [{"tag": tag, "label": tag.upper(), "tier": "small"} for tag in llm_tags],
        "custom": [], "embedding": [],
        "image": [{"short": s, "label": s.upper(), "tier": "small"} for s in image_shorts],
    }


def test_merged_inventory_is_the_union_with_owners():
    merged, owners = merge_model_inventories({
        "llamacpp": _inventory(["a", "b"]),
        "vllm": _inventory(["a", "c"]),
    })
    assert [m["tag"] for m in merged["llm"]] == ["a", "b", "c"]
    assert owners["a"] == {"llamacpp", "vllm"}
    assert owners["b"] == {"llamacpp"} and owners["c"] == {"vllm"}


def test_custom_model_section_names_its_owning_engines():
    inventory = _inventory([])
    inventory["custom"] = [{"tag": "custom", "label": "Custom"}]
    merged, owners = merge_model_inventories({"llamacpp": inventory})

    entry = build_model_entries(merged, ["llm"])[0]

    assert entry.section == "Custom LLM — llamacpp"
    assert owners["custom"] == {"llamacpp"}


def test_only_models_the_engine_holds_are_runnable():
    merged, owners = merge_model_inventories({
        "llamacpp": _inventory(["a", "b"]),
        "vllm": _inventory(["a"]),
    })
    entries = build_model_entries(merged, ["llm"])
    runnable = models_runnable_by(entries, "vllm", owners)
    assert runnable["a"] is True
    assert runnable["b"] is False, "llama.cpp-only model must not be offered under vLLM"
    assert all(models_runnable_by(entries, "llamacpp", owners).values())


def test_image_models_stay_runnable_under_every_engine():
    """Image generation goes through ComfyUI, not the inference engine."""
    merged, owners = merge_model_inventories({"llamacpp": _inventory([], ["sdxl"])})
    entries = build_model_entries(merged, ["img"])
    assert all(models_runnable_by(entries, "vllm", owners).values())


def test_a_single_engine_inventory_is_unchanged():
    merged, owners = merge_model_inventories({"llamacpp": _inventory(["a", "b"])})
    entries = build_model_entries(merged, ["llm"])
    assert all(models_runnable_by(entries, "llamacpp", owners).values())


# ── multi-engine selection ──

def test_engine_selection_parses_one_or_many():
    assert parse_engine_selection("vllm") == ["vllm"]
    assert parse_engine_selection("llamacpp,vllm") == ["llamacpp", "vllm"]
    assert parse_engine_selection(" llamacpp , vllm ") == ["llamacpp", "vllm"]
    assert parse_engine_selection("") == [] and parse_engine_selection(None) == []


def test_engine_selection_round_trips():
    for names in (["vllm"], ["llamacpp", "vllm"]):
        assert parse_engine_selection(format_engine_selection(names)) == names


def test_saved_state_naming_an_uninstalled_engine_is_reported():
    from scripts.app.benchmark_frontend import frontend_state_availability_errors, MenuEntry
    tests = [MenuEntry("llm", "LLM", "test", "Tests", True)]
    models = [MenuEntry("a", "A", "llm", "LLM", True)]
    state = {"engine": "llamacpp,mlx", "tests": ["llm"],
             "models": {"llm": ["a"], "embedding": [], "image": []}}
    errors = frontend_state_availability_errors(state, ["llamacpp", "vllm"], tests, models)
    assert any("mlx" in e for e in errors)


def test_a_fully_installed_multi_engine_state_is_accepted():
    from scripts.app.benchmark_frontend import frontend_state_availability_errors, MenuEntry
    tests = [MenuEntry("llm", "LLM", "test", "Tests", True)]
    models = [MenuEntry("a", "A", "llm", "LLM", True)]
    state = {"engine": "llamacpp,vllm", "tests": ["llm"],
             "models": {"llm": ["a"], "embedding": [], "image": []}}
    assert frontend_state_availability_errors(state, ["llamacpp", "vllm"], tests, models) == []


def test_a_state_without_an_engine_key_skips_engine_validation():
    """Portable presets carry no engine, so importing one must not fail validation
    nor override the engines already selected on screen."""
    from scripts.app.benchmark_frontend import frontend_state_availability_errors, MenuEntry
    tests = [MenuEntry("llm", "LLM", "test", "Tests", True)]
    models = [MenuEntry("a", "A", "llm", "LLM", True)]
    state = {"tests": ["llm"], "models": {"llm": ["a"], "embedding": [], "image": []}}
    assert frontend_state_availability_errors(state, ["llamacpp", "vllm"], tests, models) == []


def test_an_empty_engine_string_is_still_rejected_when_the_key_is_present():
    from scripts.app.benchmark_frontend import frontend_state_availability_errors, MenuEntry
    tests = [MenuEntry("llm", "LLM", "test", "Tests", True)]
    models = [MenuEntry("a", "A", "llm", "LLM", True)]
    state = {"engine": "", "tests": ["llm"],
             "models": {"llm": ["a"], "embedding": [], "image": []}}
    assert frontend_state_availability_errors(state, ["llamacpp"], tests, models)


# ── combined menu toggles ──

def test_llamabench_toggle_expands_to_both_native_llama_cpp_tests():
    from scripts.app.benchmark_frontend import expand_selected_tests
    assert expand_selected_tests(["llm", "llamabench"]) == [
        "llm", "llamabench", "llamabenchconc",
    ]


def test_expansion_preserves_order_and_does_not_duplicate():
    from scripts.app.benchmark_frontend import expand_selected_tests
    assert expand_selected_tests([]) == []
    assert expand_selected_tests(["conv", "llm"]) == ["conv", "llm"]
    # A CLI-shaped list already containing both must not gain a duplicate.
    assert expand_selected_tests(["llamabench", "llamabenchconc"]) == [
        "llamabench", "llamabenchconc",
    ]


def test_uncombined_tests_pass_through_expansion_untouched():
    from scripts.app.benchmark_frontend import expand_selected_tests
    assert expand_selected_tests(["vllmbench", "emb", "img"]) == ["vllmbench", "emb", "img"]


def test_collapse_maps_either_native_test_back_to_the_single_toggle():
    from scripts.app.benchmark_frontend import collapse_tests_to_entries
    assert collapse_tests_to_entries(["llm", "llamabench"]) == {"llm", "llamabench"}
    # A state saved before the toggles were combined recorded only the concurrency test.
    assert collapse_tests_to_entries(["llamabenchconc"]) == {"llamabench"}
    assert collapse_tests_to_entries(["llamabench", "llamabenchconc"]) == {"llamabench"}


def test_collapse_leaves_every_other_test_as_its_own_entry():
    from scripts.app.benchmark_frontend import collapse_tests_to_entries
    assert collapse_tests_to_entries(["llm", "conv", "vllmbench", "img"]) == {
        "llm", "conv", "vllmbench", "img",
    }
    assert collapse_tests_to_entries([]) == set()


def test_a_legacy_saved_selection_restores_the_combined_toggle():
    entries = build_test_entries(sample_inventory())
    assert apply_saved_test_selection(entries, saved_state(tests=["llamabenchconc"]))
    checked = {entry.value for entry in entries if entry.checked}
    assert checked == {"llamabench"}


def test_every_stage_a_toggle_can_produce_has_a_progress_label():
    from scripts.app.benchmark_frontend import (
        TEST_DEFINITIONS, TEST_STAGE_LABELS, expand_selected_tests,
    )
    produced = expand_selected_tests(name for name, *_ in TEST_DEFINITIONS)
    assert set(produced) <= set(TEST_STAGE_LABELS)
    assert all(TEST_STAGE_LABELS[name] for name in produced)
