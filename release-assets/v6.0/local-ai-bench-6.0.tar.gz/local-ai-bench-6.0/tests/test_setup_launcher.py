from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def test_macos_launcher_treats_gui_cancel_as_clean_exit():
    launcher = (ROOT / "Setup Local AI Bench.command").read_text()
    cancel_check = 'if [ "$status" -eq 10 ]'
    error_check = 'if [ "$status" -ne 0 ]'
    assert cancel_check in launcher
    assert launcher.index(cancel_check) < launcher.index(error_check)
    assert "osascript" not in launcher


def test_setup_wrapper_only_offers_benchmark_after_setup_check_succeeds():
    wrapper = (ROOT / "setup.sh").read_text()
    setup_call = '"$VENV_PYTHON" -m scripts.setup.setup_check "$@"'
    benchmark_prompt = 'Run the benchmark now? [y/N]'
    assert wrapper.index(setup_call) < wrapper.index(benchmark_prompt)
    assert "set -euo pipefail" in wrapper


def test_linux_setup_refreshes_apt_only_before_resolving_missing_packages():
    wrapper = (ROOT / "setup.sh").read_text()
    refresh = 'sudo apt-get update -qq'
    missing_headers = 'if [ ${#MISSING_HEADERS[@]} -gt 0 ]'
    unversioned = 'for _package in python3-venv "python${PYTHON_SERIES}-venv"'
    package_query = 'apt-cache show "$_package"'
    assert wrapper.index(refresh) < wrapper.index(missing_headers)
    assert wrapper.index(missing_headers) < wrapper.index('refresh_apt_metadata || exit 1')
    assert wrapper.index(unversioned) < wrapper.index(package_query)
    assert wrapper.count("refresh_apt_metadata || exit 1") == 2
    assert 'verify Ubuntu\'s universe repository is enabled' in wrapper


def test_setup_wrappers_do_not_offer_an_extra_run_for_qualification():
    unix = (ROOT / "setup.sh").read_text()
    windows = (ROOT / "setup.bat").read_text()
    assert '== *" --qualification "*' in unix
    assert 'if /i not "%~1"=="--qualification"' in windows


def test_linux_desktop_launcher_is_repo_relative_and_forces_gui():
    launcher = (ROOT / "Setup Local AI Bench.desktop").read_text()
    assert launcher.startswith("[Desktop Entry]\n")
    assert "Type=Application" in launcher
    assert "Terminal=true" in launcher
    assert "%k" in launcher
    assert 'cd "$(dirname "$p")"' in launcher
    assert "bash setup.sh --interface gui" in launcher


def test_windows_launcher_forces_gui_and_treats_cancel_as_clean_exit():
    launcher = (ROOT / "Setup Local AI Bench.bat").read_text()
    wrapper = (ROOT / "setup.bat").read_text()
    assert 'cd /d "%~dp0"' in launcher
    assert "call setup.bat --interface gui" in launcher
    assert "if %SETUP_STATUS% equ 10 exit /b 0" in launcher
    assert "if %errorlevel% equ 10 exit /b 10" in wrapper
