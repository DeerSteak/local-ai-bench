"""Math word-problem accuracy benchmark — see docs/workloads.md#math."""

import json
import math
import re
from pathlib import Path

from scripts.runtime import config
from scripts.runtime.shared import Shared
from scripts.workloads.accuracy_scoring import score_question_bank, validate_question_bank


class MathBenchmark:
    MATH_DATA_PATH = Path(__file__).with_name("data") / "math_questions.json"

    MATH_CRASH_CACHE = Path(".math_crash_cache.json")  # see docs/project-structure.md

    # -1 delegates the finite per-pass limits to chat's token_budget split.
    MATH_NUM_PREDICT = -1

    _NUMBER_PATTERN = r"-?\d[\d,]*\.?\d*"
    _NUMBER_RE = re.compile(_NUMBER_PATTERN)
    _BARE_NUMBER_RE = re.compile(rf"^\s*({_NUMBER_PATTERN})\s*%?\s*$")
    _BOXED_RE = re.compile(rf"\\boxed\s*\{{\s*({_NUMBER_PATTERN})\s*%?\s*\}}", re.IGNORECASE)
    _ANSWER_RE = re.compile(
        rf"\b(?:final\s+answer|answer)\b\s*(?:is|:|=)\s*"
        rf"(?:actually\s+)?(?:\$|\\?\(|\\?\[)?\s*({_NUMBER_PATTERN})",
        re.IGNORECASE,
    )
    _LEADING_NUMBER_RE = re.compile(
        rf"^\s*({_NUMBER_PATTERN})[ \t]*%?[ \t]*(?:\r?\n|$)",
    )
    _CONCLUSION_RE = re.compile(
        rf"(?:^|(?<=[.!?])|(?<=\n))[ \t]*(?:therefore|thus|so)\b[\s\S]{{0,500}}?"
        rf"\b(?:is|equals|has|gives|yields)\b\s*(?:approximately\s+)?"
        rf"({_NUMBER_PATTERN})(?![\d,.])",
        re.IGNORECASE,
    )
    _EQUAL_RESULT_RE = re.compile(
        rf"=\s*(?:approximately\s+)?({_NUMBER_PATTERN})(?![\d,.])",
        re.IGNORECASE,
    )

    @staticmethod
    def load_questions(path: Path = MATH_DATA_PATH) -> list[dict]:
        return validate_question_bank(
            json.loads(Path(path).read_text(encoding="utf-8")), ("prompt", "answer"),
        )

    @staticmethod
    def build_prompt(question: dict) -> str:
        return (
            f"{question['prompt']}\n\n"
            "Respond with only the final numeric answer, with no other text."
        )

    @staticmethod
    def parse_answer(response_text: str | None) -> float | None:
        """Extract a stated numeric result from free-form text, or None."""
        if not response_text:
            return None

        bare = MathBenchmark._BARE_NUMBER_RE.fullmatch(response_text)
        if bare:
            return MathBenchmark._to_float(bare.group(1))

        structured = [
            (match.start(), match.group(1))
            for pattern in (MathBenchmark._BOXED_RE, MathBenchmark._ANSWER_RE)
            for match in pattern.finditer(response_text)
        ]
        if structured:
            return MathBenchmark._to_float(max(structured, key=lambda candidate: candidate[0])[1])

        fallback_matches = MathBenchmark._NUMBER_RE.findall(response_text)
        fallback = fallback_matches[-1] if fallback_matches else None
        stated = []
        leading = MathBenchmark._LEADING_NUMBER_RE.match(response_text)
        if leading:
            leading_value = MathBenchmark._to_float(leading.group(1))
            fallback_value = MathBenchmark._to_float(fallback) if fallback is not None else None
            equality_value = MathBenchmark._last_completed_equality_value(response_text)
            if leading_value in (fallback_value, equality_value):
                stated.append((leading.start(1), leading.group(1)))
        for conclusion in MathBenchmark._CONCLUSION_RE.finditer(response_text):
            value = MathBenchmark._conclusion_value(response_text, conclusion)
            if value is not None:
                stated.append((conclusion.start(1), value))
        if stated:
            return MathBenchmark._to_float(max(stated, key=lambda candidate: candidate[0])[1])

        return MathBenchmark._to_float(fallback) if fallback is not None else None

    @staticmethod
    def _to_float(value: str) -> float | None:
        try:
            parsed = float(value.replace(",", ""))
        except ValueError:
            return None
        return parsed if math.isfinite(parsed) else None

    @staticmethod
    def _conclusion_value(response_text: str, match: re.Match) -> str | None:
        line_start = response_text.rfind("\n", 0, match.start()) + 1
        line_prefix = response_text[line_start:match.start()]
        if re.fullmatch(r"\s*(?:[-*]\s*)?\d+\.", line_prefix):
            return None

        tail_start = match.end(1)
        cursor = tail_start
        if cursor < len(response_text) and response_text[cursor] == "%":
            cursor += 1
        while cursor < len(response_text) and response_text[cursor] in " \t":
            cursor += 1
        if cursor == len(response_text) or response_text[cursor] not in "+-*/^=":
            return match.group(1)

        clause_end = MathBenchmark._clause_end(response_text, cursor)
        clause = response_text[cursor:clause_end]
        results = list(MathBenchmark._EQUAL_RESULT_RE.finditer(clause))
        if not results:
            return None
        result = results[-1]
        result_end = result.end(1)
        while result_end < len(clause) and clause[result_end] in "% \t":
            result_end += 1
        if result_end < len(clause) and clause[result_end] in "+-*/^=":
            return None
        return result.group(1)

    @staticmethod
    def _clause_end(response_text: str, start: int) -> int:
        for index in range(start, len(response_text)):
            char = response_text[index]
            if char in "\n;?!":
                return index
            if char == ".":
                before_digit = index > 0 and response_text[index - 1].isdigit()
                after_digit = index + 1 < len(response_text) and response_text[index + 1].isdigit()
                if not (before_digit and after_digit):
                    return index
        return len(response_text)

    @staticmethod
    def _last_completed_equality_value(response_text: str) -> float | None:
        completed = []
        for result in MathBenchmark._EQUAL_RESULT_RE.finditer(response_text):
            cursor = result.end(1)
            while cursor < len(response_text) and response_text[cursor] in "% \t":
                cursor += 1
            if cursor < len(response_text) and response_text[cursor] in "+-*/^=":
                continue
            completed.append(result.group(1))
        return MathBenchmark._to_float(completed[-1]) if completed else None

    @staticmethod
    def _ask(engine, tag: str, question: dict) -> tuple[float | None, str, bool]:
        prompt = MathBenchmark.build_prompt(question)
        measurement = engine.chat(
            tag, [{"role": "user", "content": prompt}],
            timeout=config.ACC_TIMEOUT, num_ctx=config.ACCURACY_CONTEXT,
            num_predict=MathBenchmark.MATH_NUM_PREDICT,
            check_loop=True,
            token_budget=config.ACC_TOKEN_BUDGET,
        )
        return (MathBenchmark.parse_answer(measurement.response_text),
                measurement.response_text, measurement.budget_nudged)

    @staticmethod
    def score(questions: list[dict], answers: dict) -> dict:
        """Tally correct/total overall and per category, comparing each
        answer against its own question's tolerance."""
        def evaluate(question, given):
            expected = question["answer"]
            is_correct = given is not None and abs(given - expected) <= question.get("tolerance", 0)
            return given is not None, is_correct, {
                "id": question["id"], "category": question["category"],
                "given": given, "expected": expected,
            }

        return score_question_bank(questions, answers, evaluate)

    def run(self, engine, models, questions=None, warmup_runs=config.WARMUP_RUNS, save_fn=None,
            answers_path: Path | None = None,
            telemetry=None, journal=None):  # pragma: no cover — orchestrates real engine runs
        questions = questions if questions is not None else MathBenchmark.load_questions()
        return Shared.run_accuracy_benchmark(
            section_label="Math", skip_label="math", question_noun="math questions",
            data_path=MathBenchmark.MATH_DATA_PATH, crash_cache_path=MathBenchmark.MATH_CRASH_CACHE,
            models=models, questions=questions, warmup_runs=warmup_runs, engine=engine,
            ask_fn=lambda tag, q: MathBenchmark._ask(engine, tag, q),
            rescore_partial_fn=lambda q, text: MathBenchmark.parse_answer(text),
            score_fn=MathBenchmark.score,
            save_fn=save_fn, answers_path=answers_path, progress_stage="math", telemetry=telemetry,
            journal=journal,
        )
