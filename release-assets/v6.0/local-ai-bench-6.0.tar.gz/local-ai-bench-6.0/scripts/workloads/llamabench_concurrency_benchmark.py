"""llama-batched-bench parallel-sequence throughput sweep — see docs/workloads.md#llama-bench-concurrency.
Talks to LlamaCppEngine directly rather than the InferenceEngine interface — llama-batched-bench has no cross-engine equivalent."""

import json
import platform
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path

from scripts.runtime import config
from scripts.runtime.llamacpp_tools import find_llamacpp_tool
from scripts.runtime.engines.llamacpp import LlamaCppEngine
from scripts.runtime.shared import Shared
from scripts.runtime.failure_handling import unexpected_model_failure
from scripts.runtime.progress_events import emit_model_finished, emit_progress
from scripts.runtime.pause_control import wait_if_paused
from scripts.runtime.telemetry import add_power_efficiency


class LlamaBenchConcurrencyBenchmark:
    IDLE_POLL_INTERVAL = 1.0   # how often run_one checks the idle-output watchdog below

    @staticmethod
    def find_binary() -> str | None:
        """Locate llama-batched-bench with the same policy as llama-server."""
        return find_llamacpp_tool(
            "llama-batched-bench", vendored_dir=config.LLAMACPP_DIR,
            platform_name=platform.system(), which_fn=shutil.which,
        )

    @staticmethod
    def fit_npl(pp: int, tg_values: list[int], npl_values: list[int],
                model_max: int) -> tuple[int, list[int]]:
        """Clamps prompt depth and drops concurrency levels whose unified KV need
        (pl * (pp + max_tg)) exceeds the model's real context — see docs/workloads.md#llama-bench-concurrency."""
        max_tg = max(tg_values)
        effective_pp = max(1, min(pp, model_max - max_tg))
        fitted = [npl for npl in npl_values if npl * (effective_pp + max_tg) <= model_max]
        return effective_pp, fitted or [1]

    @staticmethod
    def build_command(binary: str, model_path: Path, ctx_size: int, pp: int, tg: list[int],
                      npl: list[int], batch_size: int, ubatch_size: int,
                      ngl: int | str) -> list[str]:
        """Builds the llama-batched-bench argv — see docs/workloads.md#llama-bench-concurrency."""
        cache_type = (
            "f16" if ngl != 0 and config.LLAMACPP_GPU_SPLIT_MODE == "tensor"
            else config.LLAMACPP_KV_CACHE_TYPE
        )
        return [
            binary,
            "-m", str(model_path),
            "-c", str(ctx_size),
            "-npp", str(pp),
            "-ntg", ",".join(str(v) for v in tg),
            "-npl", ",".join(str(v) for v in npl),
            "-b", str(batch_size),
            "-ub", str(ubatch_size),
            "-ngl", str(ngl),
            *LlamaCppEngine.repack_args(),
            *LlamaCppEngine.gpu_split_args(cpu_only=ngl == 0),
            "--cache-type-k", cache_type,
            "--cache-type-v", cache_type,
            "--flash-attn", "on",
            "--output-format", "jsonl",
        ]

    @classmethod
    def run_one(cls, binary: str, model_path: Path, ctx_size: int, pp: int, tg: list[int],
                npl: list[int], batch_size: int, ubatch_size: int, ngl: int | str,
                timeout: int | float,
                on_progress=None, on_entry=None, env=None) -> list[dict]:
        """Parses each stdout JSONL row as it arrives (this build is silent on stderr, so
        that's the only progress signal). `timeout` is an idle timeout, not a wall-clock cap."""
        cmd = cls.build_command(binary, model_path, ctx_size, pp, tg, npl, batch_size, ubatch_size, ngl)
        popen_kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE, "text": True}
        if env is not None:
            popen_kwargs["env"] = env
        proc = subprocess.Popen(cmd, **popen_kwargs)
        Shared._managed_procs.append(proc)

        entries: list[dict] = []
        stderr_chunks: list[str] = []
        callback_errors: list[BaseException] = []
        pending: deque[dict] = deque()
        activity_lock = threading.Lock()
        last_activity = [time.monotonic()]

        def _touch():
            with activity_lock:
                last_activity[0] = time.monotonic()

        def _deliver_pending() -> bool:
            """Run the callbacks on the calling (main) thread. False once one has raised."""
            while True:
                with activity_lock:
                    entry = pending.popleft() if pending else None
                if entry is None:
                    return not callback_errors
                if on_entry:
                    try:
                        on_entry(entry)
                    except BaseException as exc:
                        callback_errors.append(exc)
                        return False
                if on_progress:
                    on_progress(cls.format_entry(entry))

        def _drain_stdout():
            assert proc.stdout is not None
            for line in proc.stdout:
                _touch()
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    entry = json.loads(stripped)
                except json.JSONDecodeError:
                    continue
                entries.append(entry)
                # Delivered from the main thread: callbacks persist results, and the journal's
                # SQLite connection rejects use from any thread but its creator's.
                with activity_lock:
                    pending.append(entry)

        def _drain_stderr():
            assert proc.stderr is not None
            for line in proc.stderr:
                stderr_chunks.append(line)
                _touch()

        stdout_thread = threading.Thread(target=_drain_stdout, daemon=True)
        stderr_thread = threading.Thread(target=_drain_stderr, daemon=True)
        stdout_thread.start()
        stderr_thread.start()

        idle_timed_out = False
        while proc.poll() is None:
            if not _deliver_pending():
                proc.kill()
                break
            with activity_lock:
                idle = time.monotonic() - last_activity[0]
            if idle > timeout:
                idle_timed_out = True
                proc.kill()
                break
            time.sleep(cls.IDLE_POLL_INTERVAL)

        proc.wait()
        stdout_thread.join()
        stderr_thread.join()
        if proc in Shared._managed_procs:
            Shared._managed_procs.remove(proc)
        # Entries can arrive between the last poll and process exit.
        if not idle_timed_out:
            _deliver_pending()

        if callback_errors:
            raise callback_errors[0]

        if idle_timed_out:
            error = subprocess.TimeoutExpired(cmd, timeout)
            setattr(error, "partial_entries", list(entries))
            raise error

        if proc.returncode != 0:
            raise RuntimeError(
                f"llama-batched-bench exited {proc.returncode}: {''.join(stderr_chunks).strip()[-2000:]}")
        if not entries:
            raise RuntimeError("llama-batched-bench produced no parseable JSONL output")
        return entries

    @staticmethod
    def format_entry(entry: dict) -> str:
        return (f"pp{entry.get('pp', 0)}+tg{entry.get('tg', 0)} @ {entry.get('pl', 0)}-way: "
                f"{entry.get('speed_tg', 0.0):.1f} tok/s aggregate")

    def run(self, engine, models, cpu_only=False, save_fn=None, telemetry=None, journal=None):
        results = journal.export() if journal else {}

        if not isinstance(engine, LlamaCppEngine):
            Shared.warn(f"llama-batched-bench only supports the llamacpp engine — skipping for {engine.name}")
            return results

        binary = self.find_binary()
        if binary is None:
            Shared.err("llama-batched-bench not found — run setup.sh/setup.bat to install it, or build it "
                       "yourself: https://github.com/ggml-org/llama.cpp")
            return results

        ngl = 0 if cpu_only else config.LLAMABENCH_CONC_GPU_LAYERS

        for model in models:
            tag, label, short = model["tag"], model["label"], model["short"]
            Shared.section(f"llama-batched-bench ({engine.name}): {label}")

            emit_progress("model", "llamabenchconc", "running", label, model_id=tag)
            try:
                if not engine.model_pulled(tag):
                    Shared.warn(f"{tag} not pulled — skipping")
                    Shared.warn("Download it with: python setup_check.py")
                    if journal:
                        journal.record_model_state(model, "skipped", {})
                    continue

                paths = LlamaCppEngine._resolve_model_files(tag)
                if paths is None:
                    Shared.err(f"{tag}: model files went missing between listing and run — skipping")
                    failure = {"error": "model files not found"}
                    if journal:
                        journal.record_model_state(model, "failed", failure)
                        results = journal.export()
                    else:
                        results[short] = failure
                    continue

                model_max = engine.max_context_length(tag)
                effective_pp, npl = self.fit_npl(
                    config.LLAMABENCH_CONC_PP, config.LLAMABENCH_CONC_TG,
                    config.LLAMABENCH_CONC_NPL, model_max,
                )
                ctx_size = max(npl) * (effective_pp + max(config.LLAMABENCH_CONC_TG))
                if effective_pp != config.LLAMABENCH_CONC_PP:
                    Shared.warn(f"{label}: prompt depth clamped to {effective_pp} tokens to fit the "
                                f"model's {model_max}-token context")

                entries = []
                results[short] = {
                    "entries": entries, "pp": effective_pp, "ctx_size": ctx_size,
                    "requested_cases": len(config.LLAMABENCH_CONC_TG) * len(npl),
                    "completed_cases": 0,
                }
                if journal:
                    journal.record_model_plan(
                        model, effective_pp, ctx_size,
                        len(config.LLAMABENCH_CONC_TG) * len(npl),
                    )
                    results = journal.export()
                sweeps = (journal.pending_sweeps(
                    model, effective_pp, config.LLAMABENCH_CONC_TG, npl,
                ) if journal else [(config.LLAMABENCH_CONC_TG, npl)])

                def _record_entry(entry):
                    if journal:
                        journal.record_entry(model, entry)
                        results.update(journal.export())
                        entries.append(entry)
                    elif telemetry:
                        entry["memory"] = telemetry.finish_case()
                        if (power := getattr(telemetry, "last_power", None)) is not None:
                            entry["power"] = add_power_efficiency(
                                power, "tokens_per_joule",
                                entry.get("tg", 0) * entry.get("pl", 0),
                            )
                        telemetry.begin_measured("measured:native-sweep")
                    if not journal:
                        entries.append(entry)
                        results[short]["completed_cases"] = len(entries)
                    if save_fn and not journal:
                        save_fn(results)

                try:
                    for sweep_tg, sweep_npl in sweeps:
                        wait_if_paused()
                        if journal:
                            journal.begin_measured("measured:native-sweep-includes-load")
                        elif telemetry:
                            telemetry.begin_measured("measured:native-sweep-includes-load")
                        before = len(entries)
                        try:
                            run_kwargs = {"on_progress": Shared.log, "on_entry": _record_entry}
                            if process_env := engine.process_environment():
                                run_kwargs["env"] = process_env
                            returned_entries = self.run_one(
                                binary, paths[0], ctx_size, effective_pp, sweep_tg, sweep_npl,
                                config.LLAMABENCH_BATCH_SIZE, config.LLAMABENCH_UBATCH_SIZE,
                                ngl, config.LLAMABENCH_TIMEOUT,
                                **run_kwargs,
                            )
                            if len(entries) == before:
                                for entry in returned_entries:
                                    _record_entry(entry)
                        finally:
                            if journal:
                                journal.discard_case()
                            elif telemetry:
                                telemetry.finish_case()
                    if journal:
                        journal.record_model_complete(model)
                        results = journal.export()
                except subprocess.TimeoutExpired:
                    Shared.err(f"{label}: llama-batched-bench stopped with {len(entries)} completed entries")
                    results[short]["timed_out"] = True
                    results[short]["error"] = f"no output for {config.LLAMABENCH_TIMEOUT}s (idle timeout)"
                    if journal:
                        journal.record_model_state(model, "timed_out", {
                            "timed_out": True,
                            "error": f"no output for {config.LLAMABENCH_TIMEOUT}s (idle timeout)",
                        })
                        results = journal.export()
                    continue
                except Exception as e:
                    Shared.err(f"{label}: {e}")
                    results[short]["error"] = str(e)
                    if journal:
                        journal.record_model_state(model, "failed", {"error": str(e)})
                        results = journal.export()
                    continue
                for entry in entries:
                    Shared.ok(self.format_entry(entry))
            except Exception as exc:
                Shared.err(f"{label}: unexpected error running llama-batched-bench — {exc} — "
                           "skipping remaining work for this model")
                failure = unexpected_model_failure(label, exc)
                if journal:
                    journal.record_model_state(model, "failed", failure)
                    results = journal.export()
                else:
                    results.setdefault(short, {}).update(failure)
            finally:
                if save_fn and not journal:
                    save_fn(results)
                emit_model_finished("llamabenchconc", label, results.get(short), model_id=tag)

        if journal:
            journal.finish()
            results = journal.export()
        return results
