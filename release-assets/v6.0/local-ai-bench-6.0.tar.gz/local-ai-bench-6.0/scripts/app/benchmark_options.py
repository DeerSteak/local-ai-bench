"""Typed public benchmark option metadata shared by CLI and frontends."""

from dataclasses import dataclass

from scripts.runtime import config


@dataclass(frozen=True)
class OptionSpec:
    value_type: str
    classification: str
    ui_status: str
    ui_location: str
    default: object = None
    minimum: int | None = None
    maximum: int | None = None
    choices: tuple[object, ...] = ()


TEST_CHOICES = (
    "llm", "conv", "llamabench", "llamabenchconc", "vllmbench", "emb", "mcq", "math",
    "reasoning", "code", "tool", "acc", "conc_tool", "conc_chat", "conc", "sustained", "img",
)
TG_TOKEN_CHOICES = (128, 512, 1024)
TIER_CHOICES = ("xsmall", "small", "medium", "large")
MTP_CHOICES = ("off", "on", "both")


def _spec(value_type, classification, ui_status, ui_location, **kwargs):
    return OptionSpec(value_type, classification, ui_status, ui_location, **kwargs)


PUBLIC_OPTION_SCHEMA = {
    "--quick": _spec(
        "boolean", "guided", "excluded", "CLI smoke-test scope differs from GUI Quick run",
        default=False,
    ),
    "--dry-run": _spec("boolean", "contextual", "equivalent", "Final plan preview", default=False),
    "--tests": _spec("string-list", "guided", "exposed", "Test selection screen", choices=TEST_CHOICES),
    "--engine": _spec("choice", "guided", "exposed", "Engine selection screen"),
    "--llm-models": _spec("string-list", "guided", "exposed", "LLM model selection screen"),
    "--models": _spec("string-list", "guided", "equivalent", "Alias of --llm-models"),
    "--model-variant": _spec("string-list", "guided", "exposed", "LLM model selection screen"),
    "--embedding-models": _spec("string-list", "guided", "exposed", "Embedding model selection screen"),
    "--image-models": _spec("string-list", "guided", "exposed", "Image model selection screen"),
    "--max-prompt-tokens": _spec("integer", "guided", "exposed", "Prompt-processing cap screen", minimum=1),
    "--tg-tokens": _spec("integer-list", "guided", "exposed", "Generation-size screen", choices=TG_TOKEN_CHOICES),
    "--maxtier": _spec("choice", "guided", "equivalent", "Explicit model selection is more precise", choices=TIER_CHOICES),
    "--list-models": _spec("boolean", "contextual", "equivalent", "Installed models appear in selection screens", default=False),
    "--sample": _spec("integer", "developer-only", "excluded", "Developer-only non-comparable accuracy sampling", minimum=1),
    "--fork-plan": _spec("path", "developer-only", "excluded", "Internal reviewed-fork provenance guard"),
    "--warmup": _spec("integer", "advanced", "exposed", "Graphical execution settings", default=config.WARMUP_RUNS, minimum=0),
    "--runs": _spec("integer", "advanced", "exposed", "Graphical execution settings", default=config.N_RUNS, minimum=1, maximum=10),
    "--timeout": _spec("integer", "advanced", "exposed", "Graphical execution settings", default=300, minimum=1),
    "--acc-timeout": _spec("integer", "advanced", "exposed", "Graphical execution settings", default=config.ACC_TIMEOUT, minimum=1),
    "--acc-token-budget": _spec("integer", "advanced", "exposed", "Graphical execution settings", default=config.ACC_TOKEN_BUDGET, minimum=1),
    "--cpu-only": _spec("boolean", "advanced", "exposed", "Graphical execution settings", default=False),
    "--gpu-split-mode": _spec(
        "choice", "advanced", "exposed", "Graphical execution settings",
        default="layer", choices=("single", "layer", "tensor"),
    ),
    "--mtp": _spec(
        "choice", "advanced", "exposed", "Graphical execution settings",
        default="off", choices=MTP_CHOICES,
    ),
    "--llamacpp-no-repack": _spec(
        "boolean", "advanced", "exposed", "Graphical execution settings", default=False,
    ),
    "--force-all": _spec("boolean", "advanced", "exposed", "Graphical execution settings", default=False),
    "--retry-crashed-models": _spec(
        "boolean", "advanced", "exposed", "Graphical execution settings", default=False,
    ),
    "--offline": _spec("boolean", "advanced", "exposed", "Graphical execution settings", default=False),
    "--memory-telemetry": _spec(
        "boolean", "advanced", "exposed", "Graphical execution settings", default=True,
    ),
    "--power-telemetry": _spec(
        "boolean", "advanced", "exposed", "Graphical execution settings", default=False,
    ),
    "--sustained-duration": _spec(
        "integer", "advanced", "exposed", "Graphical execution settings",
        default=config.SUSTAINED_DURATION_SEC, minimum=config.SUSTAINED_MIN_CLASSIFICATION_SEC,
    ),
    "--ambient-temp-c": _spec(
        "number", "advanced", "exposed", "Graphical execution settings", default=None,
        minimum=-100, maximum=100,
    ),
    "--out": _spec("path", "advanced", "exposed", "Graphical path settings", default=""),
    "--comfyui": _spec("path", "advanced", "exposed", "Graphical path settings", default=""),
}


GUI_OPTION_FLAGS = {
    "warmup": "--warmup", "runs": "--runs", "timeout": "--timeout",
    "acc_timeout": "--acc-timeout", "acc_token_budget": "--acc-token-budget",
    "cpu_only": "--cpu-only", "gpu_split_mode": "--gpu-split-mode",
    "mtp": "--mtp",
    "llamacpp_no_repack": "--llamacpp-no-repack",
    "force_all": "--force-all", "retry_crashed_models": "--retry-crashed-models",
    "offline": "--offline", "memory_telemetry": "--memory-telemetry",
    "power_telemetry": "--power-telemetry",
    "sustained_duration": "--sustained-duration", "ambient_temp_c": "--ambient-temp-c",
    "out": "--out",
    "comfyui": "--comfyui",
}


def gui_option_defaults() -> dict:
    return {key: PUBLIC_OPTION_SCHEMA[flag].default for key, flag in GUI_OPTION_FLAGS.items()}


def option_value_errors(values: dict[str, object]) -> list[str]:
    errors = []
    for flag, value in values.items():
        spec = PUBLIC_OPTION_SCHEMA[flag]
        if value is None:
            continue
        if spec.value_type == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                errors.append(f"{flag} must be a whole number.")
                continue
            if spec.minimum is not None and value < spec.minimum:
                errors.append(f"{flag} must be at least {spec.minimum}.")
            if spec.maximum is not None and value > spec.maximum:
                errors.append(f"{flag} must be at most {spec.maximum}.")
        elif spec.value_type == "number":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                errors.append(f"{flag} must be a number.")
                continue
            if spec.minimum is not None and value < spec.minimum:
                errors.append(f"{flag} must be at least {spec.minimum}.")
            if spec.maximum is not None and value > spec.maximum:
                errors.append(f"{flag} must be at most {spec.maximum}.")
        elif spec.value_type == "choice" and value not in spec.choices:
            errors.append(f"{flag} must be one of: {', '.join(str(choice) for choice in spec.choices)}.")
    return errors
